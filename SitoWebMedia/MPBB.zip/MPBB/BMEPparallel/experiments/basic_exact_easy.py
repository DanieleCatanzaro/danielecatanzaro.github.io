import glob
import os
import itertools
import numpy as np
import time
import sys
import subprocess

MIN_N = 10
MAX_N = 30
TIMELIMIT = 3600
STOP_AFTER_TIMEOUT = True
REPORT_FILE = "report_easy_exact.txt" 

EXEC = "../BME-Solver"
INST_DIR = "../../instances"
OUTPUT_DIR = "./output"


PARAMS="-ordertaxa=3"

os.environ["DYLD_LIBRARY_PATH"] =  "/Applications/FICO-Xpress/xpressmp/lib"

def read_cropped_matrix(mat,n):
    m = []
    with open(mat, "r") as file:
        mat_n = int(file.readline())


        m.extend([[float(num) for num in line.split()] for line in file])
    m = np.reshape(m, (mat_n, mat_n))
    return [m[i][0:n] for i in range(n)]

def get_n(inst):
    with open(inst, "r") as file:
        n = int(file.readline())
    return n

def compute_cost(inst, sol):
    n = len(inst)
    return sum([inst[i][j]*pow(2.0,n-sol[i][j]) for (i,j) in itertools.product(range(n), range(n))])

def run_inst(instance, n):
    name = instance[instance.rfind("/"):instance.rfind(".")]
    outfile = OUTPUT_DIR + name + "_" + str(n)+ "_heu.sol"
    cmd = EXEC + " "  + instance + " -taxa=" + str(n) + "  " + PARAMS + " -maxruntime=" + str(TIMELIMIT) + " | grep \"+++\" >> " + REPORT_FILE 
    print(cmd)
    start_time = time.time()
    os.system(cmd)
    #subprocess.check_output(cmd)
    end_time = time.time()
    tot_time = end_time-start_time
    if tot_time > TIMELIMIT*0.999:
        return True
    return False



def run_exp():
    os.system("mv %s prev_report.txt"%REPORT_FILE)
    instances = sorted(glob.glob(INST_DIR+"/*txt"))
    for inst in instances:
        max_n = get_n(inst)
        if MIN_N > max_n:
            continue

        for n in range(MIN_N,min(MAX_N,max_n)+1):
            #print("%s %d"%(inst, n))
            if run_inst(inst,n) and STOP_AFTER_TIMEOUT:
                break
    
    
    


if __name__ == "__main__":
    run_exp()
