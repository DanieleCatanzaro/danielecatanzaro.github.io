import glob
import os
import itertools
import numpy as np
import time
import sys

TIMELIMIT = 3600
REPORT_FILE = "report_hard_other.txt" 

EXEC = "../BME-Solver"
INST_DIR = "../../instances/supplement"
OUTPUT_DIR = "./output"


PARAMS="-ordertaxa=2 -cores=28"
def read_cropped_matrix(mat,n):
    m = []
    with open(mat, "r") as file:
        mat_n = int(file.readline())


        m.extend([[float(num) for num in line.split()] for line in file])
    m = np.reshape(m, (mat_n, mat_n))
    return [m[i][0:n] for i in range(n)]

def get_n(inst):
    with open(inst, "r") as file:
        n = int(file.readline())
    return n

def compute_cost(inst, sol):
    n = len(inst)
    return sum([inst[i][j]*pow(2.0,n-sol[i][j]) for (i,j) in itertools.product(range(n), range(n))])

def run_inst(instance):
    name = instance[instance.rfind("/"):instance.rfind(".")]
    cmd = EXEC + " "  + instance + "  -newick" + PARAMS + " -maxruntime=" + str(TIMELIMIT) + " | grep \"+++\" >> " + REPORT_FILE 
    print(cmd)
    start_time = time.time()
    os.system(cmd)
    #subprocess.check_output(cmd)
    end_time = time.time()
    tot_time = end_time-start_time
    if tot_time > TIMELIMIT*0.999:
        return True
    return False

def run_exp():
    os.system("mv %s prev_report.txt"%REPORT_FILE)
    instances = sorted(glob.glob(INST_DIR+"/*txt"))
    for inst in instances:
        run_inst(inst)
   
    
    


if __name__ == "__main__":
    run_exp()
