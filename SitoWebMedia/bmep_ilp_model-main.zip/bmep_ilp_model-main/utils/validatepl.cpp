#include "../src/instance.hpp"
#include "../src/tsp.hpp"
#include "../src/validation.hpp"
#include <cmath>

#include<boost/program_options.hpp>

namespace po = boost::program_options;

int main(int argc, char **argv) {
    std::string solfilename;
    std::string instfilename;
    char obj;
    bool linear_obj=false;
    double eps;
    bool first_only;

    po::options_description options("Tool for validating path-length solrices.");
    po::variables_map vm;
    options.add_options()
        ("help,h", "Display help menu.")
        ("sol,s", po::value<std::string>()->default_value(""), "Solution file (Path-Length Matrix).")
        ("inst,i", po::value<std::string>()->default_value(""), "(Optional) Instance file (Path-Length Matrix). If provide, cost is computed.")
        ("obj,O", po::value<char>()->default_value('B'), "Objective Function: (B)MEP or (L)inear")
        ("eps,e", po::value<double>()->default_value(1e-6), "Tolerance for floating point comparisons.")
        ("firstonly,f", "Shows only the first violation of each type for triangular inequalities, buneman.");
    po::store(po::parse_command_line(argc, argv, options), vm);    
    po::notify(vm);

    solfilename = vm["sol"].as<std::string>();
    instfilename = vm["inst"].as<std::string>();
     if(vm.count("help") || solfilename.size() == 0) {
        std::cout << options << std::endl;
        return 0;
    }
    obj = vm["obj"].as<char>();
    linear_obj = (obj != 'B' && obj != 'b');
    eps = vm["eps"].as<double>();
    first_only = vm.count("firstonly");

    NumMatrix<int> sol = read_square_matrix<int>(solfilename);
    int n = sol.size();

    if(!is_pathlength_matrix(sol)) {
        std::cout << "CONTRACTIONS FAILED!!!" << std::endl;


        //test triangular
        auto tri_violations = find_violated_triangular_inequalities(sol, 1e-6, first_only);
        for(auto violation: tri_violations) {
            std::cout << "TRI VIOLATED: "
                      << violation.taxa[0] << " "
                      << violation.taxa[1] << " "
                      << violation.taxa[2] << std::endl;
            std::cout << "\tSlack: " << violation.slack << std::endl;
            if(violation.weak) {
                std::cout << "Weak" << std::endl;
            }
        }

        //test buneman
        for(auto violation: find_violated_buneman_inequalities(sol, 1e-6, first_only)) {
            std::cout << "BUNEMAN VIOLATED: "
                      << violation.taxa[0] << " "
                      << violation.taxa[1] << " "
                      << violation.taxa[2] << " "
                      << violation.taxa[3] << std::endl;
            std::cout << "\t" << violation.lhs << " > max(" 
                      << violation.first_rhs << ", " << violation.second_rhs << ")"
                      << std::endl;
        }

        //test kraft
        for(auto violation: find_violated_kraft_inequalities(sol, eps)) {
            std::cout << "KRAFT VIOLATED " << violation.taxa << std::endl;
            std::cout << "\tLHS: " << violation.lhs << std::endl;
        }

        ManifoldViolation manifold_violation;
        if(is_manifold_violated(sol, manifold_violation, eps)) {
            std::cout << "MANIFOLD VIOLATED" << std::endl;
            std::cout << "\t" << manifold_violation.lhs << "/" << 2*n-3 << std::endl;
        }
 

        for(auto violation: find_violated_circular_orders(sol, eps)) {
            std::cout << "CIRC ORDER VIOLATED, sum is " << violation.cost<< ":" << std::endl << "\t";
            for(auto t: violation.tour) {
                std::cout << t << " ";
            }
            std::cout << violation.tour[0] << std::endl;
        }

        for(auto cut: find_violated_generalized_kraft_inequalities(sol, eps)) {
            std::cout << "GENERALIZED KRAFT VIOLATED: " << cut.cost
                      << "/" << pow(2,n-2) << std::endl << "\t";
            for(auto s: cut.S) {
                std::cout << s << " ";
            }
            std::cout << std::endl;
        }
    } else {
        std::cout << "Valid UBT." << std::endl;
        if(instfilename.size() > 0) {
            auto inst = read_square_matrix<double>(instfilename);
            crop(inst, sol.size());
            if(linear_obj) {
               std::cout << "Cost: " << compute_linear_cost(inst, sol);
            } else {
                std::cout << "Cost: " << compute_bmep_cost(inst, sol) << std::endl;
                std::cout << "Scaled cost: " << compute_scaled_bmep_cost(inst, sol) << std::endl;

            }
            
        }
    }

    return 0;
}