#pragma once 
#include "instance.hpp"

#include <locale>

//IMPORTANT: assumes leaves are labeled L1 to LN and correspond to the first N vertices in the graph
//very simplified newick format

std::string _double_converter(double v) {
    if(v < 1e-8) {
        v = 0;
    }
    std::ostringstream str;
    str << std::fixed << std::setprecision(8) << v;
    return str.str();
}

std::string _writer_dfs_helper(const Graph &g, int n, int u, int parent) {
    if(u < n) {
        return "L"+std::to_string(u+1);
    }

    std::string ret = "(";
    bool first = true;
    for(int v: make_iterator_range( boost::adjacent_vertices(u,g))) {
        if(v != parent) {
            if(!first) {
                ret += ", ";
            }
            first = false;
            Edge edge = boost::edge(u,v,g).first;
            double weight = get(boost::edge_weight_t(), g, edge);
            ret += _writer_dfs_helper(g, n, v, u) + ":" + _double_converter(weight);
        }
    }
    ret += ")";

    return ret;
}

void write_newick_file(const Graph &g, std::string filename) {
    int n=(num_vertices(g)+2)/2;
    std::ofstream ofs(filename);
    ofs << _writer_dfs_helper(g, n, n, -1) << ";" << std::endl;
    ofs.close();
}



//simple parser to avoid adding dependencies to the project
//leaves are labeled "L<id>".

// simplified newick grammar
// length => double
// leaf_label => Lint
// tree => descendant_list: length;
// descendant_list => (subtree {, subtree})
// subtree => descendant_list :length | leaf_label :branch_length

class SimpleNewickParser {
    Graph _g;

    int _parse_int(const std::string &s, int &pos) {
        int v = 0;
        int sign = 1;
        if(s[pos] == '+') {
            pos++;
        } else if(s[pos] == '-') {
            sign = -1;
            pos++;
        }

        while(pos < s.size() && isdigit(s[pos])) {
            v *= 10;
            v += s[pos] - '0';
            pos++;
        }
        return v*sign;
    }
    double _parse_double(const std::string &s, int &pos) {
        double v = _parse_int(s, pos);
        if(s[pos] == '.') {
            pos++;
            int old_pos = pos;
            int decimal = _parse_int(s,pos);
            v += (1.0)*decimal*pow(10,-(pos-old_pos));
        }
        return v;
    }

    void _parse_leaf(const std::string &s, int &pos, Vertex parent) {
        pos++;
        int label = _parse_int(s, pos);
        double length = 0;
        if(s[pos] == ':') {
            pos++;
            length = _parse_double(s, pos);
        }
        add_edge(parent, label-1, length, _g);

    }
    void _parse_subtree(const std::string &s, int &pos, Vertex parent) {
        pos++;
        bool done = false;
        Vertex vertex = add_vertex(_g);
        while(!done) {
            switch(s[pos]) {
                case ',':
                    pos++;
                    break;
                case '(':
                    _parse_subtree(s, pos, vertex);
                    break;
                case 'L':
                    _parse_leaf(s, pos, vertex);
                    break;
                case ')':
                    pos++;
                    done = true;
                    break;
            }
        }
        double length = 0;
        if(s[pos] == ':') {
            pos++;
            length = _parse_double(s, pos);
        }

        add_edge(vertex, parent, length, _g);
        //pos++;

    }
    public:
    Graph parse_newick(const std::string &s) {
        int pos=0;
        int n = std::count(s.begin(), s.end(), 'L');
        _g = Graph(n);
        bool done = false;
        Vertex vertex = add_vertex(_g);
        while(pos < s.size() && !done) {
            switch(s[pos]) {
                case '(':
                    _parse_subtree(s, pos, vertex);
                    break;
                case 'L':
                    _parse_leaf(s, pos, vertex);
                    break;
                case ';':
                    done = true;
                    break;
                default:
                    pos++;
            }

        }
        return _g;
    }

};


Graph parse_newick_string(std::string s) {
    SimpleNewickParser parser;
    s.erase(remove_if(s.begin(), s.end(), isspace), s.end()); //remove spaces
    return parser.parse_newick(s);
}


Graph parse_newick_file(std::string filename) {
    std::ifstream ifs(filename);
    std::string newick_string;
    getline(ifs, newick_string);
    Graph g = parse_newick_string(newick_string);
    ifs.close();
    return g;
}
