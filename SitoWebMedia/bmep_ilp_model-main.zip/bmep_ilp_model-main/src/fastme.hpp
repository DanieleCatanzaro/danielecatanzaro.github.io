#pragma once
#include "instance.hpp"
#include "newick.hpp"

template<typename T>
void _write_fastme_temp_inst(const NumMatrix<T> &mat, std::string filename) {
    std::ofstream ofs(filename);
    int n = matrix_size(mat).first; 
    ofs << n << std::endl;
    for(int i=0; i < n; i++) {
        ofs << "L" << (i+1);

        for(int j=0; j < n; j++) {
            double v = mat[i][j];
            if(v < 1e-8) {
                v = 0;
            }
            ofs << " " << std::fixed << std::setprecision(8) << v;
        }
        ofs << std::endl;
    }
    ofs.close();
}

template<typename Tin, typename Tout>
NumMatrix<Tout> run_fastme_local_search(const NumMatrix<Tin> &inst, const NumMatrix<Tout> &sol,
        bool nni=false, bool spr=false) {
    int rand_id = rand();
    std::string inst_filename = std::filesystem::temp_directory_path().string() + "/fi" + std::to_string(rand_id) + ".inst";
    std::string in_nw_filename = std::filesystem::temp_directory_path().string() + "/fi" + std::to_string(rand_id) + ".nw";
    std::string out_nw_filename = std::filesystem::temp_directory_path().string() + "/fi" + std::to_string(rand_id) + "_sol.nw";
    
    _write_fastme_temp_inst(inst, inst_filename);
    write_newick_file(pathlengths_to_graph(sol), in_nw_filename);
    std::string arguments;
    arguments += " --input_data=" + inst_filename;
    arguments += " --output_tree=" + out_nw_filename;
    arguments += " --method=U";
    arguments += " --user_tree=" + in_nw_filename;

    if(nni) {
        arguments += " --nni=balME";
    }

    if(spr) {
        arguments += " --spr";
    }

    std::string cmd = "fastme" + arguments;
    std::cout << cmd << std::endl;
    int ret = system(cmd.c_str());
    if(ret != 0) {
        return sol;
    }

    return graph_to_pathlengths<Tout>(parse_newick_file(out_nw_filename));
}

template<typename Tin, typename Tout>
NumMatrix<Tout> run_fastme(const NumMatrix<Tin> &inst,
        bool nni=false, bool spr=false) {
    int rand_id = rand();
    std::string inst_filename = std::filesystem::temp_directory_path().string() + "/fi" + std::to_string(rand_id) + ".inst";
    std::string out_nw_filename = std::filesystem::temp_directory_path().string() + "/fi" + std::to_string(rand_id) + "_sol.nw";
    _write_fastme_temp_inst(inst, inst_filename);
    std::string arguments;
    arguments += " --input_data=" + inst_filename;
    arguments += " --output_tree=" + out_nw_filename;
    arguments += " --method=BioNJ";
    if(nni) {
        arguments += " --nni=balME";
    }

    if(spr) {
        arguments += " --spr";
    }

    std::string cmd = "fastme" + arguments;
    std::cout << cmd << std::endl;
    int ret = system(cmd.c_str());
    if(ret != 0) {
        return NumMatrix<Tout>();
    }
    auto sol = graph_to_pathlengths<Tout>(parse_newick_file(out_nw_filename));
    write_newick_file(pathlengths_to_graph(sol), "test.nw");
    return sol;
}