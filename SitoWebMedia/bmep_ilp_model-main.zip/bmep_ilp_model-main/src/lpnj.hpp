#pragma once
#include "instance.hpp"
#include <functional>
//using GreedyFunc = std::vector<TaxaPair> ()(const NumMatrix<T1> inst, const NumMatrix<T1> relax, const std::vector )



struct TaxaPairCost {
    int i, j;
    double cost;


    TaxaPairCost(int i, int j, double cost=0.0) {
        this->i = i;
        this->j = j;
        this->cost = cost;
    }

    TaxaPairCost() : TaxaPairCost(-1, -1) {

    }

    bool operator <(const TaxaPairCost& other) const {
        return cost < other.cost-1e-8;
    }
};



typedef std::function<void(const NumMatrix<double>&, const NumMatrix<double>&, TaxaPairCost&)> GreedyFunc;

//output: updates taxa_pair evaluation
void greedy_relax_nj_eval(const NumMatrix<double> &inst, const NumMatrix<double> &relax,
        TaxaPairCost &taxa_pair) {
    int n = inst.size();
    int i = taxa_pair.i;
    int j = taxa_pair.j;

    taxa_pair.cost = (n-2)*relax[i][j];
    for(int k=0; k < n; k++) {
        taxa_pair.cost -= (relax[i][k] + relax[j][k]);
    }
}


void greedy_inst_nj_eval(const NumMatrix<double> &inst, const NumMatrix<double> &relax,
        TaxaPairCost &taxa_pair) {
    int n = inst.size();
    int i = taxa_pair.i;
    int j = taxa_pair.j;

    taxa_pair.cost = (n-2)*inst[i][j];
    for(int k=0; k < n; k++) {
        taxa_pair.cost -= (inst[i][k] + inst[j][k]);
    }
}

//output: sol becomes the path-length matrix and the weighted graph is returned
Graph lpnj(NumMatrix<double> inst,
        NumMatrix<double> relax, NumMatrix<int> &sol,
        int k=1,
        GreedyFunc primary=&greedy_relax_nj_eval,
        GreedyFunc secondary=&greedy_inst_nj_eval) {
    int n = matrix_size(inst).first;
    Graph g(n);

    //helper to map contracted matrix's taxa and vertices of g
    std::vector<Vertex> index2vertex(n);
    for(int i=0; i < n; i++) {
        index2vertex[i] = i;
    }


    //contract until there are only two vertices;
    while(n > 2) {
        std::vector<TaxaPairCost> cands;
        cands.reserve(n*(n-1)/2);
        for(int i=0; i < n; i++) {
            for(int j=i+1; j < n; j++) {
                TaxaPairCost tpc(i,j);
                primary(inst, relax, tpc);
                cands.push_back(tpc);

            }
        }
        
        //TODO: can be optimized
        std::sort(cands.begin(), cands.end()); // TODO rewrite as heap
        cands.resize(std::min(k, (int)cands.size()));

        for(int l = 0; l < cands.size(); l++) {
            secondary(inst, relax, cands[l]);
        }

        std::sort(cands.begin(), cands.end()); //TODO: rewrite as max
        int i = cands[0].i;
        int j = cands[0].j;
        


        //create new vertex and connect it to contracted pair
        auto v = add_vertex(g);
        double cost_vi = 0.5*inst[i][j];
        for(int other=0; other < n; other++) {
            cost_vi += inst[i][other];
            cost_vi -= inst[j][other];
        }
        cost_vi /= 2*(n-2);

        add_edge(v, index2vertex[i], cost_vi, g);
        add_edge(v, index2vertex[j], inst[i][j] - cost_vi, g);


        contract(inst, i, j);
        contract(relax, i, j);
        //update index two vertex map
        index2vertex[i] = v;
        for(int k=j+1;k < n;k++) {
            index2vertex[k-1] = index2vertex[k];
        }
        index2vertex.resize(n-1);

        n--;
    }

    //connect remaining two vertices
    add_edge(index2vertex[0], index2vertex[1], inst[0][1], g);

    sol = graph_to_pathlengths<int>(g);
    return g;
}