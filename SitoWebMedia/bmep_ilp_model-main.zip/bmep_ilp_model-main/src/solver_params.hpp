#pragma once

enum StrTriangularInqType {
    ST_NONE,
    ST_ONE,
    ST_ALL,
};

enum BunemanType {
    BN_NONE,
    BN_ONE,
    BN_ALL,
};

enum CircularOrderSepaMethod {
    CO_NONE,
    CO_GREEDY,
    CO_EXACT
};

enum ObjFunc {
    OBJ_BMEP,
    OBJ_LINEAR
};

enum InstPerm {
    IP_NONE,
    IP_TSP_GREEDY,
    IP_TSP_EXACT,
    IP_MAX_MIN,
    IP_MIN_MAX
};

#define DISABLE_CUT -1

struct CutTolPerc {

    double root;
    double non_root;

    CutTolPerc(double root=DISABLE_CUT, double non_root=DISABLE_CUT) :
        root(root),
        non_root(non_root) {
    }
};


struct CuttingPlanesSettings {
    CutTolPerc circ_orders;
    CutTolPerc c2k_splits;
    CutTolPerc weak_bunemans;
    CutTolPerc GKI;


    CuttingPlanesSettings() :
        circ_orders(0.05, 0.005),
        GKI(0.05, 0.01),
        weak_bunemans(0.125, DISABLE_CUT),
        c2k_splits(0.001, DISABLE_CUT) {
    }
};