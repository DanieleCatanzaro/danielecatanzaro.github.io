#pragma once
#include <queue>


struct Sets2KSplit {
    std::array<int, 2> S1;
    std::vector<int> S2;
};


std::vector<std::vector<int>> precompute_2K_coefs(int n) {
    std::vector<std::vector<int>> coefs;
    coefs.resize(n);
    for(int i = 2; i < n;i++) {
        coefs[i].resize(n-1);
    }
    for(int l=2; l < n; l++) {
        std::vector<std::priority_queue<int, std::vector<int>, std::greater<int>>>
            queues(l-1); //min priority queues represent each subtree
        int sum_queues=l-1;
        std::vector<int> max_queue(l-1, 1);
        //prepares queues internal node
        for(int i=0; i < l-1; i++) {
            queues[i].push(1);
        }
        //if l is sufficiently large, each taxa is adjacent to the path 12
        for(int K=1; K <= l-2; K++) {
            coefs[l][K] = K*(l+2);
        }

        int cur_queue = 0;
        for(int K=l-1; K < n-2; K++) {
            int min_elem = queues[cur_queue].top();
            queues[cur_queue].pop();
            queues[cur_queue].push(min_elem+1);
            queues[cur_queue].push(min_elem+1);  
            max_queue[cur_queue] = std::max(max_queue[cur_queue], min_elem+1);
            sum_queues += min_elem+2;
            coefs[l][K] = 2*(sum_queues-(max_queue[cur_queue]))+K*l;
            cur_queue = (cur_queue+1)%(l-1);
        }
        coefs[l][n-2] = 2*sum_queues+(n-2)*l;
    }
    return coefs;
}


std::vector<Sets2KSplit> find_violated_2k_splits(const std::vector<std::vector<int>> &coefs, int minK, int maxK,
        double perc_tol, bool lift,
        const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<double> &tau) {
    std::vector<Sets2KSplit> ret;
    int _n = tau.size();

    for(int i = 0; i < _n; i++) {
        for(int j = i+1; j < _n; j++) {
            std::vector<std::pair<double, int>> cost_taxa;
            cost_taxa.reserve(_n-2);
            for(int k = 0; k < _n; k++) {
                if(k == i || k == j) {
                    continue;
                } 
                cost_taxa.emplace_back(std::make_pair(tau[i][k]+tau[j][k], k));
            }
            std::sort(cost_taxa.begin(), cost_taxa.end());

            
            for(int K=minK; K <= maxK; K++) {
                double min_lhs = 0;
                for(int k = 0; k < K; k++) {
                    min_lhs += cost_taxa[k].first;
                }
                double rhs = 0;
                if(lift) {
                    rhs = 0;
                    for(int l=2; l < _n; l++) {
                        rhs += coefs[l][K]*tau_disc[i][j][l];
                    }
                } else {
                    rhs = coefs[2][K];
                    for(int l =3; l < _n; l++) {
                        rhs = std::min(rhs, (double)coefs[l][K]);
                    }
                }
                
                if(min_lhs < rhs*(1-perc_tol)) {
                    Sets2KSplit cut;
                    cut.S1 = {i,j};
                    for(int k = 0; k < K; k++) {
                        cut.S2.push_back(cost_taxa[k].second);
                    }
                    ret.push_back(cut);
                    break;//one K per S1
                }
            }
        }
            
    }
    return ret;
}
                             