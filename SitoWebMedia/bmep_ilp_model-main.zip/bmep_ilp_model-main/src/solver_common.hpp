#pragma once 
#include <chrono>

#include "solver_params.hpp"
#include "common.hpp"
#include "instance.hpp"
#include "report.hpp"
#include "tsp.hpp"
#include "lpnj.hpp"
#include "fastme.hpp"
#include "precompute_2K_coefs.hpp"
//helper function to isolate permutation generating and avoid inconsistencies
std::vector<std::array<int, 4>> _generate_buneman_permutations(const std::array<int,4> &quad) {
    return {{quad[0], quad[1], quad[2], quad[3]},
            {quad[0], quad[2], quad[1], quad[3]},
            {quad[0], quad[3], quad[1], quad[2]}};
}
//makes sure that i < j and p < q
std::array<int, 4> _sorted_buneman_quad(int i, int j , int p, int q) {
    if(i > j) {
        std::swap(i,j);
    } 
    if(p > q) {
        std::swap(p,q);
    }
    return {i,j,p,q};
}


class SolverInterface {
    protected:
    //input info
    NumMatrix<double> _inst;
    int _n;

    CuttingPlanesSettings _cutting_planes_settings; // separation thresholds
    bool _lift; // perform discretized tau lift?

    //data produced by a run
    NumMatrix<double> _best_sol;
    Report _report;

    // settings
    ObjFunc _obj_func;
    bool _relax;

    int _lpnj_k; // greedy parameter for the heuristic, 0 disables it
    bool _lpnj_localsearch; // use fastme localsearch?
    bool _swa_br; // use swa branching rule? only supported by SCIP
    

    StrTriangularInqType _str_tri; // how to handle strong triangular inequality: no lift, only taxa 1, all taxa 
    BunemanType _buneman_type; // how to handle buneman constraints: none, one taxa (same as str tri), all

    InstPerm _perm_type; // how to permutate the input matrix
    std::vector<int> _perm; // actual permutation

    CircularOrderSepaMethod _co_method; //how to handle circular orders: no separation, greedy separation or exact separation
    bool _gki; // separate generalized kraft inequalities?
    bool _weak_bunemans; // separate spread quartets 
    bool _2K_splits; // separate 2K splits

    double _timelimit; //max runtime for the lp solver in seconds, negative time disables timelimit
    std::vector<double> powers_of_two;
    void compute_powers_of_two() {
        powers_of_two.resize(_n);
        powers_of_two[0]= 1;
        for(int i = 1; i < _n; i++) {
            powers_of_two[i] = powers_of_two[i-1]*2.0;
        }
    }

    virtual void setup_model() = 0;
    
    virtual void create_variables() = 0;

    virtual void create_convexity_cons() = 0;

    virtual void create_kraft_cons() = 0;

    virtual void create_manifold_con() = 0;

    virtual void create_triangular_cons() = 0;

    virtual void create_buneman_cons() = 0;

    void create_cons() {
        create_convexity_cons();
        create_kraft_cons();
        create_manifold_con();
        create_triangular_cons();
        create_buneman_cons();
    }

    virtual void load_custom_plugins() = 0;

    virtual void solve_model() = 0;

    virtual void construct_solution() = 0;

    virtual void print_stats() = 0;
    
    virtual bool separate_root_cuts(const std::vector<std::vector<int>> &c2K_coefs) = 0;

    virtual double get_solver_obj() = 0;

    void solve_root_node() {
        int nrounds = 0;
        
        std::vector<std::vector<int>> c2K_coefs;

        if(_2K_splits && _cutting_planes_settings.c2k_splits.root != DISABLE_CUT) {
            c2K_coefs = precompute_2K_coefs(_n);
        }
        do {
            solve_model();
            if(nrounds == 0) {
                _report.first_root_bound = get_solver_obj();
            } 
            _report.last_root_bound = get_solver_obj();
            
            nrounds++;
        } while(separate_root_cuts(c2K_coefs));
    }
    public:

    SolverInterface() :
        _obj_func(OBJ_BMEP),
        _relax(false),
        _cutting_planes_settings(CuttingPlanesSettings()),
        _lift(false),
        _lpnj_k(0),
        _lpnj_localsearch(false),
        _gki(false),
        _weak_bunemans(false),
        _swa_br(false),
        _co_method(CO_NONE),
        _str_tri(ST_NONE),
        _buneman_type(BN_NONE),
        _2K_splits(false),
        _perm_type(IP_NONE),
        _timelimit(-1) {
            _perm.clear();
        
    }

    virtual NumMatrix<double> solve(NumMatrix<double> &inst) {
        
         _n = matrix_size(inst).first;

        _perm.resize(_n);
        if(_perm_type == IP_NONE) {
            for(int i = 0; i < _n; i++) {
                _perm[i] = i;
            }
        } else if(_perm_type == IP_TSP_GREEDY) {
            _perm = greedy_nn_tsp(inst, 0, _n);
            local_search_2opt_tsp(inst, _perm);
            
        } else if(_perm_type == IP_TSP_EXACT) {
            std::vector<int> cands(_n);
            for(int i = 0; i < _n; i++) {
                cands[i] = i;
            }
            _perm = exact_tsp(inst, cands, 1e-8);
        } if(_perm_type == IP_MAX_MIN || _perm_type == IP_MIN_MAX) {
            std::vector<std::pair<double,int>> value_leaf(_n);
            for(int i = 0; i < _n; i++) {
                double value = 0;
                if(_perm_type == IP_MAX_MIN) {
                    value = -*std::max_element(inst[i].begin()+i+1, inst[i].end());
                } else {
                    //avoid the 0
                    if(i == 0) {
                        value = *std::min_element(inst[i].begin()+1, inst[i].end());
                    } else if (i == _n-1) {
                        value = *std::min_element(inst[i].begin(), inst[i].end()-1);
                    } else {
                        value = std::min(*std::min_element(inst[i].begin(), inst[i].begin()+i),
                                         *std::min_element(inst[i].begin()+i+1, inst[i].end()));
                    }
                    
                }
                value_leaf[i] = std::make_pair(value, i);
            }
            std::sort(value_leaf.begin(), value_leaf.end());
            for(int i = 0; i < _n; i++) {
                _perm[i] = value_leaf[i].second;
            }
        }

        std::cout << "Input permutation applied (" << compute_tour_cost(inst, _perm) << ")";
        for(int i = 0; i < _n; i++) {
            std::cout << " "  << _perm[i];
        }
        std::cout << std::endl;
        _inst = apply_perm(inst, _perm);
       
        _report = Report();
        _report.n = _n;
        if(_relax) {
            std::cout << "Solving root relaxation" << std::endl;
        }
        print_cutting_planes_info();
        auto start_time = std::chrono::high_resolution_clock::now();
        compute_powers_of_two();
        setup_model();
        create_variables();
        create_cons();

        load_custom_plugins();
        if(_relax) {
            solve_root_node();
        } else {
            solve_model();
        }

        auto stop_time = std::chrono::high_resolution_clock::now();
        construct_solution();

        print_stats();
        if(_relax && _lpnj_k > 1) {
            NumMatrix<int> heu_sol;
            auto g = lpnj(_inst, _best_sol, heu_sol, _lpnj_k);
    
            if(_lpnj_localsearch) {
                heu_sol = run_fastme_local_search(_inst, heu_sol, true, true);
            }
            for(int i = 0; i < _n; i++) {
                for(int j = 0; j < _n; j++) {
                    _best_sol[i][j] = heu_sol[i][j];
                }
            }
            _report.node_best_sol = 0;
        }
        if(_obj_func == OBJ_BMEP) {
            _report.sol = compute_scaled_bmep_cost(_inst, _best_sol);
        } else {
            _report.sol = compute_linear_cost(_inst, _best_sol);
        }
        _report.time = std::chrono::duration_cast<std::chrono::nanoseconds>(stop_time-start_time).count()*1e-9;

        _inst = apply_reverse_perm(_inst, _perm);
        _best_sol = apply_reverse_perm(_best_sol, _perm);
        return _best_sol;
    }

    std::string _tol2str(double tol) {
        std::ostringstream stream;   
        if (tol > 0) {
            stream << std::fixed << std::setprecision(4) << tol;
            return stream.str();
        } else {
            return "------";
        }
    }

    void print_cutting_planes_info() {
        if(_lift) {
            std::cout << "Discretized Tau Lifting Enabled" << std::endl;
        }
        std::cout << "--- CUTTING PLANES ----" << std::endl;
        if(_gki) {
            std::cout << "GKI      " << _tol2str(_cutting_planes_settings.GKI.root);
            std::cout << " | " << _tol2str(_cutting_planes_settings.GKI.non_root) << std::endl;
        }
        if(_co_method != CO_NONE) {
            char method;
            if(_co_method == CO_GREEDY) {
                method = 'G';
            } else {
                method = 'E';
            }
            std::cout << "CO(" << method << ")    " << _tol2str(_cutting_planes_settings.circ_orders.root);
            std::cout << " | " << _tol2str(_cutting_planes_settings.circ_orders.non_root) << std::endl;
        }
        
        if(_weak_bunemans) {
            std::cout << "WB       " << _tol2str(_cutting_planes_settings.weak_bunemans.root);
            std::cout << " | " << _tol2str(_cutting_planes_settings.weak_bunemans.non_root) << std::endl;
        }

        if(_2K_splits) {
            std::cout << "2Ksplits " << _tol2str(_cutting_planes_settings.c2k_splits.root);
            std::cout << " | " << _tol2str(_cutting_planes_settings.c2k_splits.non_root) << std::endl;
        }
        std::cout << "-----------------------" << std::endl;

    bool _2K_splits;
    }
    virtual void export_model(std::string filename) const  = 0;
 
    void set_cutting_planes_settings(CuttingPlanesSettings settings) {
        _cutting_planes_settings = settings;
    }

    void set_lift(bool lift) {
        _lift = lift;
    }
    void set_obj_func(ObjFunc obj_func) {
        _obj_func = obj_func;
    }
    
    void set_lpnj_k(int k) {
        _lpnj_k = k;
    }

    void set_lpnj_localsearch(int use) {
        _lpnj_localsearch = use;
    }
    void set_use_swa_br(bool use) {
        _swa_br = use;
    }

    void set_circular_order_method(CircularOrderSepaMethod method) {
        _co_method = method;
    }

    void set_strong_triangular_type(StrTriangularInqType type) {
        _str_tri = type;
    }

    void set_buneman_type(BunemanType type) {
        _buneman_type = type;
    }

    void set_separate_gki(bool separate) {
        _gki = separate;
    }

    void set_separate_weak_bunemans(bool separate) {
        _weak_bunemans = separate;
    }

    void set_separate_2K_splits(bool separate) {
        _2K_splits = separate;
    }

    void set_timelimit(double timelimit_secs) {
        _timelimit = timelimit_secs;
    }

    void set_perm_type(InstPerm type) {
        _perm_type = type;
    }

    void relax_variables(bool relax) {
        _relax = relax;
    }

    Report get_report() const {
        return _report;
    }

    virtual ~SolverInterface() {
    }
};
