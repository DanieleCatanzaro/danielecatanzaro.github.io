#pragma once

#include "solver_common.hpp"
#include "tsp.hpp"
#include "circular_orders.hpp"
#include "min_cut.hpp"
#include "huffmanhedron_cuts.hpp"
#include "weak_bunemans_cuts.hpp"


#include "validation.hpp"
#include <gurobi_c++.h>

#include <map>

void _print_dists(const std::vector<std::vector<std::vector<double>>> &tau_disc,
        const NumMatrix<double> &tau) {
    int n = tau_disc.size();
    for(int i = 0; i < n; i++) {
        double sum_tau = 0;
        double sum_xL = 0;
        for(int j = 0; j < n; j++) {
            if(j > i) {
                std::cout << i << " " << j << "("<< tau[i][j] << "):";
                for(int l = 2; l < n; l++) {
                    std::cout << " "  << tau_disc[i][j][l];
                }
                std::cout << std::endl;
            }
            sum_tau += tau[i][j];
            sum_xL += tau_disc[i][j][n-1];
            
        }
        std::cout << "\t" << sum_tau << " " << sum_xL << std::endl;
    }
}

class SolverGurobiCB: public GRBCallback {
    int _n;

    CuttingPlanesSettings _cutting_planes_settings; // separation thresholds
    bool _lift; // perform discretized tau lift?

    const NumMatrix<double> &_inst;
    Report &_report;

    const std::map<Triplet, GRBVar> &_x;//x variables indicating \tau_{ij} = l
    const std::map<Triplet, GRBVar> &_s;//slack variables for triangular inequalities
    const std::map<std::array<int,4>, GRBVar> &_y; //buneman indicators

    //parameters
    bool _lazy;
    int _lpnj_k; //heuristic parameter
    bool _lpnj_localsearch; //run localsearch

    CircularOrderSepaMethod _co_method; //method for separation of circular order inqs

    bool _gki; // separate generalized kraft inqs
    bool _weak_bunemans;// separate spread quarts
    bool _2K_splits; // separate 2K cuts

    int _call_cnt;

    std::vector<std::vector<int>> _2K_coefs;

    void add_projected_buneman_cut(const NumMatrix<double> & tau, const std::array<int, 4> &taxa) {
        GRBLinExpr expr=0;
        for(int i = 0; i < 4; i++) {
            for(int j = i+1; j < 4; j++) {
                expr += _x.at({taxa[i], taxa[j], int(tau[i][j])});
            }
        }
        addLazy(expr, GRB_LESS_EQUAL, 5);
    }

    NumMatrix<double> get_tau(bool relax) {
        auto tau = zero_matrix<double>(_inst.size());
        for(int i = 0; i < _n; i++) {
            for(int j = i+1; j < _n; j++) {
                for(int l = 2; l < _n; l++) {
                    double val = 0;
                    if(relax) {
                        val = getNodeRel(_x.at({i,j,l}));
                    } else {
                        val = getSolution(_x.at({i,j,l}));
                    }
                    tau[i][j] += l*val;
                    tau[j][i] += l*val;
                }
            }
        }
        return tau;
    }

    std::vector<std::vector<std::vector<double>>> get_tau_disc(bool relax) {
        std::vector<std::vector<std::vector<double>>> tau_disc;
        tau_disc.resize(_n);
        for(int i = 0; i < _n; i++) {
            tau_disc[i].resize(_n);
            for(int j = 0; j < _n; j++) {
                tau_disc[i][j].assign(_n, 0);
            }
        }
        for(int i = 0; i < _n; i++) {
            for(int j = i+1; j < _n; j++) {
                for(int l = 2; l < _n; l++) {
                    double val = 0;
                    if(relax) {
                        val = getNodeRel(_x.at({i,j,l}));
                    } else {
                        val = getSolution(_x.at({i,j,l}));
                    }
                    tau_disc[i][j][l] = val;
                    tau_disc[j][i][l] = val;
                }
            }
        }
        return tau_disc;
    }

    bool is_primal_improv(const NumMatrix<int> &sol, bool relax) {
        double cost = compute_scaled_bmep_cost(_inst, sol);
        double best_cost;
        if(relax) {
            best_cost = getDoubleInfo(GRB_CB_MIPNODE_OBJBST);
        } else {
            best_cost = getDoubleInfo(GRB_CB_MIPSOL_OBJBST);
        }

        return (cost < best_cost*0.999999);
        
    }
    void run_heuristic(const NumMatrix<double> &tau, bool is_root) {
        NumMatrix<int> sol;
        auto g = lpnj(_inst, tau, sol, _lpnj_k);
        
        if(_lpnj_localsearch && (is_primal_improv(sol, true) || (is_root &&  _call_cnt < 3))) {
            sol = run_fastme_local_search(_inst, sol, true, true);
        }

        if(is_primal_improv(sol, true)) {
            _report.node_best_sol = getDoubleInfo(GRB_CB_MIPNODE_NODCNT);
        }
        for(int i = 0; i < _n; i++) {
            for(int j = i+1; j < _n; j++) {
                //x variables
                for(int l = 2; l < _n; l++) {
                    if(sol[i][j] == l) {
                        setSolution(_x.at({i,j,l}), 1);
                    }
                }
            }
        }

        for(const auto s: _s) {
            int i = s.first[0];
            int k = s.first[1];
            int j = s.first[2];

            setSolution(s.second, (sol[i][k] + sol[k][j]-sol[i][j])/2);
        }

        for(auto y: _y) {
            int i = y.first[0];
            int j = y.first[1];
            int p = y.first[2];
            int q = y.first[3];

            if(i > j || j > p || p > q) { // canonical sorted
                continue;
            }
            

            if(sol[i][j]+sol[p][q] < sol[i][p]+sol[j][q]) { //ijpq is the shortest
                setSolution(_y.at({i,j,p,q}), 1); 
            } else if(sol[i][p]+sol[j][q] < sol[i][j]+sol[p][q]) {  //ipjq is the shortest
                setSolution(_y.at({i,p,j,q}), 1); 
            } else { //iqjp is the shortest
                setSolution(_y.at({i,q,j,p}), 1); 
            }
        }
    }

    bool separate_circular_order(const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<double> &tau, 
            bool is_root, bool relax) {
        bool violation_found=false;

        double perc_tol = 0;
        if(is_root) {
            if(_cutting_planes_settings.circ_orders.root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.circ_orders.root;
            }
        } else {
            if(_cutting_planes_settings.circ_orders.non_root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.circ_orders.non_root;
            }
        }
        
        for(const auto cut: find_circular_order_violation(perc_tol, _lift, relax, _co_method == CO_EXACT,
                                                          tau_disc, tau)) {
            GRBLinExpr expr=0;                                                
            for(int i = 0; i < cut.tour.size(); i++) {
                for(int l = 2; l < _n; l++) {
                    expr += l*_x.at({cut.tour[i], cut.tour[(i+1)%cut.tour.size()], l});
                }
                if(_lift) {
                    for(int j = 0; j < cut.tour.size(); j++) {
                        if(i != j && (i+1)%cut.tour.size() != j && (j+1)%cut.tour.size() == i) {
                            expr -= _x.at({cut.tour[i],cut.tour[j], 2});
                        }
                    }
                }
            }
            violation_found = true;
            if(relax) {
                addCut(expr >= 4*_n-8);
                
            } else {
                std::cout << "CO rejected sol" << std::endl;
                print(tau);
                addLazy(expr >= 4*_n-8);
            }

            if(is_root) {
                _report.num_circular_order_root += 1;
            } else {
                _report.num_circular_order_search += 1;
            }
        }
        
        return violation_found;
    }


    bool  separate_generalized_kraft(const std::vector<std::vector<std::vector<double>>> &tau_disc, bool is_root) {
        double perc_tol = 0;
        if(is_root) {
            if(_cutting_planes_settings.GKI.root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.GKI.root;
            }
        } else {
            if(_cutting_planes_settings.GKI.non_root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.GKI.non_root;
            }
        }

        bool violation_found = false;
        double tol = 0.005;

        Cut cut = find_min_cut_xspace(tau_disc);
        if(cut.cost < 0.5*(1-perc_tol)) {
            //std::cout << "GKI: " << cut.cost << "/" << 0.5 << std::endl;
            GRBLinExpr expr=0;
            for(int l=2; l < _n; l++) {
                for(int u: cut.S) {
                    for(int v: cut.S_complement) {
                        expr += pow(2, -l)*_x.at({u,v,l});
                    }
                }
            }
            addCut(expr >= 0.5);
            if(is_root) {
                _report.num_gki_root += 1;
            } else {
                _report.num_gki_search += 1;
            }
        }
        return violation_found;
    }


    bool separate_weak_bunemans(const std::vector<std::vector<std::vector<double>>> &tau_disc,
            const NumMatrix<double> &tau, bool is_root) {
        
        double perc_tol = 0;
        if(is_root) {
            if(_cutting_planes_settings.weak_bunemans.root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.weak_bunemans.root;
            }
        } else {
            if(_cutting_planes_settings.weak_bunemans.non_root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.weak_bunemans.non_root;
            }
        }

        bool violation_found = false;

        auto quarts = separate_weak_bunemans_cuts(perc_tol, _lift, tau_disc, tau);
        
        std::map<int, SpreadQuart> best_quart_per_u;
        for(const auto & quart: quarts) {
            if(best_quart_per_u.count(quart.u) == 0 || best_quart_per_u[quart.u].lhs > quart.lhs) {
                best_quart_per_u[quart.u] = quart;
            }

        }

        for(const auto u_quart: best_quart_per_u) {
            const SpreadQuart quart = u_quart.second;
            GRBLinExpr expr=0;
            for(int l = 2; l < _n; l++) {
                expr += l*_x.at({quart.i, quart.u, l});
                expr += l*_x.at({quart.u, quart.j, l});
                expr -= l*_x.at({quart.i, quart.j, l});
                
                expr += l*_x.at({quart.j, quart.u, l});
                expr += l*_x.at({quart.u, quart.k, l});
                expr -= l*_x.at({quart.j, quart.k, l});
                
                expr += l*_x.at({quart.i, quart.u, l});
                expr += l*_x.at({quart.u, quart.k, l});
                expr -= l*_x.at({quart.i, quart.k, l});
            }
	        if(_lift) {
                for(int v=0; v < _n; v++) {
                    if(v == quart.u || v == quart.i || v == quart.j || v == quart.k) {
                        continue;
                    }
                    expr -= 6*_x.at({quart.u, v, 2});
                }
            }
            
            addCut(expr, GRB_GREATER_EQUAL, 8);
            violation_found = true;
            if(is_root) {
                _report.num_spread_quad_root += 1;
            } else {
                _report.num_spread_quad_search += 1;
            }
        }
        return violation_found;
    }

    //prototype
    bool separate_2K_split(const std::vector<std::vector<std::vector<double>>> &tau_disc,
            const NumMatrix<double> &tau, bool is_root) {
        double perc_tol = 0;
        if(is_root) {
            if(_cutting_planes_settings.c2k_splits.root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.c2k_splits.root;
            }
        } else {
            if(_cutting_planes_settings.c2k_splits.non_root == DISABLE_CUT) {
                return false;
            } else {
                perc_tol = _cutting_planes_settings.c2k_splits.non_root;
            }
        }
        bool violation_found = false;
        
        for(const auto cut: find_violated_2k_splits(_2K_coefs, 1, 4, perc_tol, _lift,
                                tau_disc, tau)) {
            GRBLinExpr expr_lhs = 0;

            for(int v : cut.S2) {
                for(int l = 2; l < _n; l++) {
                    expr_lhs += l*_x.at({cut.S1[0],v,l});
                    expr_lhs += l*_x.at({cut.S1[1],v,l});
                }
            }
            GRBLinExpr expr_rhs = 0;
            int K = cut.S2.size();
            if(_lift) {
                for(int l=2; l < _n; l++) {
                    expr_rhs += _2K_coefs[l][K]*_x.at({cut.S1[0],cut.S1[1],l});
                }
            } else {
                int rhs = _2K_coefs[2][K];
                for(int l =3; l < _n; l++) {
                    rhs = std::min(rhs, _2K_coefs[l][K]);
                }
                expr_rhs = rhs;
            }
            
            addCut(expr_lhs >= expr_rhs);
            violation_found = true;

            if(is_root) {
                _report.num_2K_root++;
            } else {
                _report.num_2K_search++;
            }
        }
        return violation_found;
    }
    protected:
    void callback () {
        
        bool is_root=true;
        if(where == GRB_CB_MIPNODE) { //relax
            is_root = getDoubleInfo(GRB_CB_MIPNODE_NODCNT) < 1;
            if(is_root) {
                    if(_call_cnt == 0) {
                        _report.first_root_bound = getDoubleInfo(GRB_CB_MIPNODE_OBJBND);
                    }
                    _report.last_root_bound = getDoubleInfo(GRB_CB_MIPNODE_OBJBND);
            }
            if(getIntInfo(GRB_CB_MIPNODE_STATUS) == GRB_OPTIMAL) {
                _call_cnt += 1;
                auto tau = get_tau(true);
                auto tau_disc = get_tau_disc(true);

                bool violation_found = false;
                if(is_root) {
                    //_print_dists(tau_disc, tau);
                }

                if(_lpnj_k > 0) {
                    run_heuristic(tau, is_root);
                }
                if(_co_method != CO_NONE) {
                    if(separate_circular_order(tau_disc, tau, is_root, true)) {
                        violation_found = true;
                    }

                }

                if(_gki) {
                    if(separate_generalized_kraft(tau_disc, is_root)) {
                        violation_found = true;
                    }
                }

                if(_weak_bunemans) {
                    if(separate_weak_bunemans(tau_disc, tau, is_root)) {
                        violation_found = true;
                    }
                }

                if(_2K_splits) {
                    if(separate_2K_split(tau_disc, tau, is_root)) {
                        violation_found = true;
                    }
                }
                
            }
        } else if(_lazy && where == GRB_CB_MIPSOL) { //integer sol
            auto tau = get_tau(false);
            auto tau_disc = get_tau_disc(false);
            is_root = getDoubleInfo(GRB_CB_MIPSOL_NODCNT) < 1;
            if(!is_pathlength_matrix(tau)) {
                bool violation_found = false;
                _report.num_sol_rejected += 1;
                std::cout << "SOL REJECTED" << std::endl;
                if(_co_method != CO_NONE) {
                    violation_found = separate_circular_order(tau_disc, tau, is_root, false);
                }

                if(!violation_found) {
                    auto buneman_violations = find_violated_buneman_inequalities(tau, 1e-6, true);
                    for(auto violation: buneman_violations) {
                        add_projected_buneman_cut(tau, violation.taxa);
                        if(is_root) {
                            _report.num_buneman_root += 1;
                        } else {
                            _report.num_buneman_search += 1;
                        }
                    }
                }
            }

        }
        
    }
    public:
    SolverGurobiCB(const NumMatrix<double> &inst, Report &report,
            CuttingPlanesSettings cutting_planes_settings,
            bool lift,
            bool lazy,
            const std::map<Triplet, GRBVar> &x,
            const std::map<Triplet, GRBVar> &s,
            const std::map<std::array<int,4>, GRBVar> &y,
            int lpnj_k, 
            bool  lpnj_localsearch, 
            CircularOrderSepaMethod co_method,
            bool gki, bool weak_bunemans, bool sep_2Ksplits) :
            _inst(inst),
            _report(report),
            _cutting_planes_settings(cutting_planes_settings),
            _lift(lift),
            _lazy(lazy),
            _x(x),
            _s(s),
            _y(y),
            _lpnj_k(lpnj_k),
            _lpnj_localsearch(lpnj_localsearch),
            _co_method(co_method),
            _gki(gki),
            _weak_bunemans(weak_bunemans),
            _2K_splits(sep_2Ksplits),
            _n(inst.size()), 
            _call_cnt(0) {
        if(_2K_splits) {
            _2K_coefs = precompute_2K_coefs(_n);
        }
    }


};
class SolverGurobi : public SolverInterface {
    protected:
    //Gurobi data
    GRBEnv* _env;
    GRBModel* _model;
    SolverGurobiCB* _cb;

    std::map<Triplet, GRBVar> _x;//x variables indicating \tau_{ij} = l
    std::map<Triplet, GRBVar> _s;//slack variables for triangular inequalities
    std::map<std::array<int,4>, GRBVar> _y; //buneman indicators

    void setup_model() {
        _env = new GRBEnv();
        _model = new GRBModel(_env);
        _model->set(GRB_IntAttr_ModelSense, GRB_MINIMIZE);
        _model->set(GRB_DoubleParam_MIPGap, 1e-8);
        if(_timelimit > 0) {
            _model->set(GRB_DoubleParam_TimeLimit, _timelimit);
        }
        
    }

    void create_variables() {
        for(int i = 0; i < _n; i++) {
            for(int j = i+1; j < _n; j++) {
                //x
                for(int l = 2; l < _n; l++) {
                    double cost = _inst[i][j];
                    if(_obj_func == OBJ_BMEP)
                        cost *= powers_of_two[_n+1-l];
                    else {
                        cost *= l;
                    }
                    
                    std::string name = "x["+std::to_string(i)+","
                            +std::to_string(j)+","
                            +std::to_string(l)+"]";
                    char vtype = GRB_BINARY;
                    if(_relax) {
                        vtype = GRB_CONTINUOUS;
                    }
                    GRBVar var = _model->addVar(0,1,cost,vtype,name);
                    _x[{i,j,l}] = var;
                    _x[{j,i,l}] = var;
                }
                //s
                for(int k = 0; k < _n; k++) {
                    bool strong = (_str_tri == ST_ALL) ||
                                  (_str_tri == ST_ONE && (i == 0 || k == 0));
                    if(k == i || k == j || !strong) {
                        continue;
                    }
                    char vtype = GRB_INTEGER;
                    if(_relax) {
                        vtype = GRB_CONTINUOUS;
                    }
                    std::string name = "s["+std::to_string(i)+","
                            +std::to_string(k)+","
                            +std::to_string(j)+"]";
                    _s[{i,k,j}] = _model->addVar(1,_n-1,0,vtype,name);
                }
            }
        }

        //buneman
        if(_buneman_type != BN_NONE) {
            std::vector<int> cand_first;//
            if(_buneman_type == BN_ONE) {
                cand_first = {0};
            } else {
                cand_first.reserve(_n);
                for(int i = 0; i < _n; i++) {
                    cand_first.push_back(i);
                }
            }


            //probably could use some symmetry breaking
            for(int i: cand_first) {
                for(int j = i+1; j < _n; j++) {
                    for(int p = j+1; p < _n; p++) {
                        for(int q = p+1; q < _n; q++) {
                            for(auto quad: _generate_buneman_permutations({i, j, p, q})) {
                                std::string name = "y["+
                                    std::to_string(quad[0])+","+
                                    std::to_string(quad[1])+","+
                                    std::to_string(quad[2])+","+
                                    std::to_string(quad[3])+"]";
                                char vtype = GRB_BINARY;
                                if(_relax) {
                                    vtype = GRB_CONTINUOUS;
                                }
                                _y[quad] = _model->addVar(0,1,0,vtype,name);
                            }
                        }
                    }
                }
            }
        }

    }

    void create_convexity_cons() {
        for(int i=0; i < _n; i++) {
            for(int j=i+1; j < _n; j++) {
                GRBLinExpr expr=0;
                for(int l=2; l < _n; l++) {
                    expr += _x[{i,j,l}];
                }
                _model->addConstr(expr == 1, "conv"+std::to_string(i)+","+std::to_string(j));
            }
        }
    }

    void create_kraft_cons() {
        for(int i=0; i < _n; i++) {
            GRBLinExpr expr=0;
            for(int j=0; j < _n; j++) {
                if(j == i) {
                    continue;
                }
                for(int l=2; l < _n; l++) {
                    expr += _x[{i,j,l}]/powers_of_two[l];
                }
            }
            _model->addConstr(expr == 0.5, "kraft"+std::to_string(i));
        }
    }

    void create_manifold_con() {
        GRBLinExpr expr=0;
        for(int i=0; i < _n; i++) {
            for(int j=i+1; j < _n; j++) {
                for(int l=2; l < _n; l++) {
                    expr += 2*l*_x[{i,j,l}]/powers_of_two[l];
                }
            }
        }
        _model->addConstr(expr == 2*_n-3, "manifold");
    }


    void create_triangular_cons() {
        for(int i = 0; i < _n; i++) {
            for(int j = i+1; j < _n; j++) {
                for(int k=0; k < _n; k++) {
                    GRBLinExpr expr=0;
                    if(k == i || k == j) {
                        continue;
                    }
                    for(int l=2; l < _n; l++) {
                        expr += l*_x[{i,k,l}];
                        expr += l*_x[{k,j,l}];
                        expr -= l*_x[{i,j,l}];
                    }
                    bool strong = (_str_tri == ST_ALL) ||
                                  (_str_tri == ST_ONE && (i == 0 || k == 0));
                    if(_lift) {
                        for(int v=0; v < _n; v++) {
                            if(v == i || v == j || v == k) {
                                continue;
                            }
                            expr -= 2*_x.at({k, v, 2});
                        }
                    }

                    if(strong) {
                        _model->addConstr(expr == 2*_s[{i,k,j}],
                            "str_tri["+std::to_string(i)+","+
                            std::to_string(k)+","+std::to_string(j)+"]");
                    } else {
                        _model->addConstr(expr >= 2,
                            "tri["+std::to_string(i)+","+
                            std::to_string(k)+","+std::to_string(j)+"]");
                    }
                }
            }
        }
    }

    void create_buneman_cons() {
        for(auto qv: _y) {
            int i = qv.first[0];
            int j = qv.first[1];
            int p = qv.first[2];
            int q = qv.first[3];

            int M = 2*(_n-2);
            if(i > j || j > p || p > q) {
                continue;
            }
            GRBLinExpr expr=0;
            for(auto quad: _generate_buneman_permutations({i, j, p, q})) {
                expr += _y[quad];
            }
            _model->addConstr(expr == 1);
            

            //precomputing sums to simplify expressions
            GRBLinExpr tij=0;
            GRBLinExpr tip=0;
            GRBLinExpr tiq=0;
            GRBLinExpr tjp=0;
            GRBLinExpr tjq=0;
            GRBLinExpr tpq=0;

            for(int l = 2; l < _n; l++) {
                tij += l*_x[{i,j,l}];
                tip += l*_x[{i,p,l}];
                tiq += l*_x[{i,q,l}];

                tjp += l*_x[{j,p,l}];
                tjq += l*_x[{j,q,l}];

                tpq += l*_x[{p,q,l}];
            }
            _report.num_buneman_root += 6;
            int lazy_attr=1;
            //first pair: ij-pq has the shortest length
            //ij-pq vs ip-jq
            _model->addConstr(
                tip+tjq >= tij+tpq+2*(1-_y[{i,q,j,p}])-M*(_y[{i,p,j,q}])).set(GRB_IntAttr_Lazy,lazy_attr);
            //ij-pq vs iq-jp
            _model->addConstr(
                tiq+tjp >= tij+tpq+2*(1-_y[{i,p,j,q}])-M*(_y[{i,q,j,p}])).set(GRB_IntAttr_Lazy,lazy_attr);
            
            //second pair: ip-jq has the shortest length
            //ip-jq vs ij-pq
            _model->addConstr(
                tij+tpq >= tip+tjq+2*(1-_y[{i,q,j,p}])-M*(_y[{i,j,p,q}])).set(GRB_IntAttr_Lazy,lazy_attr);
            //ip-jq vs iq-jp
            _model->addConstr(
                tiq+tjp >= tip+tjq+2*(1-_y[{i,j,p,q}])-M*(_y[{i,q,j,p}])).set(GRB_IntAttr_Lazy,lazy_attr);

            //third pair: iq-jp has the shortest length
            //iq-jp vs ij-pq
            _model->addConstr(
                tij+tpq >= tiq+tjp+2*(1-_y[{i,p,j,q}])-M*(_y[{i,j,p,q}])).set(GRB_IntAttr_Lazy,lazy_attr);
            //iq-jp vs ip-jq
            _model->addConstr(
                tip+tjq >= tiq+tjp+2*(1-_y[{i,j,p,q}])-M*(_y[{i,p,j,q}])).set(GRB_IntAttr_Lazy,lazy_attr);

        }
    }

    void load_custom_plugins() {
        if(_swa_br) {
            std::cout << "WARNING: SWA branching not supported by gurobi. Feature disabled." << std::endl;
        }
        bool lazy = _buneman_type == BN_NONE;
        bool cutting_planes = _co_method != CO_NONE || _gki || _weak_bunemans || _2K_splits;
        bool heu = _lpnj_k > 0;

        if(lazy || cutting_planes || heu) {
            
            _cb = new SolverGurobiCB(_inst, _report,
                _cutting_planes_settings, _lift,
                lazy,
                _x, _s, _y,
                _lpnj_k,  _lpnj_localsearch, 
                _co_method, _gki, _weak_bunemans, _2K_splits);

            _model->setCallback(_cb);
            if(lazy) {
                _model->set(GRB_IntParam_LazyConstraints, 1);
            }
            if(heu) {
                _model->set(GRB_IntParam_MIPFocus, 3);
                _model->set(GRB_DoubleParam_Heuristics, 0);
            }

            if(cutting_planes) {
                _model->set(GRB_IntParam_PreCrush, 1);
            }
        } 
    }

    bool separate_root_cuts(const std::vector<std::vector<int>> &c2K_coefs) {

        auto tau = zero_matrix<double>(_inst.size());

        std::vector<std::vector<std::vector<double>>> tau_disc;
        tau_disc.resize(_n);
        for(int i = 0; i < _n; i++) {
            tau_disc[i].resize(_n);
            for(int j = 0; j < _n; j++) {
                tau_disc[i][j].assign(_n, 0);
            }
        }
        for(int i = 0; i < _n; i++) {
            for(int j = i+1; j < _n; j++) {
                for(int l = 2; l < _n; l++) {
                    double val = _x[{i,j,l}].get(GRB_DoubleAttr_X);

                    tau_disc[i][j][l] = val;
                    tau_disc[j][i][l] = val;

                    tau[i][j] += l*val;
                    tau[j][i] += l*val;
                }
            }
        }

        bool violation_found = false;
        if(_co_method != CO_NONE && _cutting_planes_settings.circ_orders.root != DISABLE_CUT) {
            for(const auto cut: find_circular_order_violation(_cutting_planes_settings.circ_orders.root, _lift, true, _co_method == CO_EXACT,
                                                          tau_disc, tau)) {
                _report.num_circular_order_root += 1;
                violation_found = true;
                GRBLinExpr expr=0;                                                
                for(int i = 0; i < cut.tour.size(); i++) {
                    for(int l = 2; l < _n; l++) {
                        expr += l*_x.at({cut.tour[i], cut.tour[(i+1)%cut.tour.size()], l});
                    }
                    if(_lift) {
                        for(int j = 0; j < cut.tour.size(); j++) {
                            if((i+1)%cut.tour.size() != j && (j+1)%cut.tour.size() == i) {
                                expr -= _x.at({cut.tour[i],cut.tour[j], 2});
                            }
                        }
                    }
                }
                
                _model->addConstr(expr >= 4*_n-8);
            } 
        }
        if(_gki && _cutting_planes_settings.GKI.root != DISABLE_CUT) {
            Cut cut = find_min_cut_xspace(tau_disc);
            if(cut.cost < 0.5*(1-_cutting_planes_settings.GKI.root)) {
                _report.num_gki_root += 1;
                violation_found = true;
                GRBLinExpr expr=0;
                for(int l=2; l < _n; l++) {
                    for(int u: cut.S) {
                        for(int v: cut.S_complement) {
                            expr += pow(2, -l)*_x.at({u,v,l});
                        }
                    }
                }
                _model->addConstr(expr >= 0.5);
            }
        }
        if(_weak_bunemans && _cutting_planes_settings.weak_bunemans.root != DISABLE_CUT) {
            auto quarts = separate_weak_bunemans_cuts(_cutting_planes_settings.weak_bunemans.root, _lift, tau_disc, tau);

            std::map<int, SpreadQuart> best_quart_per_u;
            for(const auto & quart: quarts) {
                if(best_quart_per_u.count(quart.u) == 0 || best_quart_per_u[quart.u].lhs > quart.lhs) {
                    best_quart_per_u[quart.u] = quart;
                }
            }

            for(const auto u_quart: best_quart_per_u) {
                _report.num_spread_quad_root += 1;
                violation_found = true;
                

                const SpreadQuart quart = u_quart.second;
                GRBLinExpr expr=0;
                for(int l = 2; l < _n; l++) {
                    expr += l*_x.at({quart.i, quart.u, l});
                    expr += l*_x.at({quart.u, quart.j, l});
                    expr -= l*_x.at({quart.i, quart.j, l});

                    expr += l*_x.at({quart.j, quart.u, l});
                    expr += l*_x.at({quart.u, quart.k, l});
                    expr -= l*_x.at({quart.j, quart.k, l});

                    expr += l*_x.at({quart.i, quart.u, l});
                    expr += l*_x.at({quart.u, quart.k, l});
                    expr -= l*_x.at({quart.i, quart.k, l});
                }
	            if(_lift) {
                    for(int v=0; v < _n; v++) {
                        if(v == quart.u || v == quart.i || v == quart.j || v == quart.k) {
                            continue;
                        }
                        expr -= 6*_x.at({quart.u, v, 2});
                    }
                }

                _model->addConstr(expr >= 8);
            }
        }
        if(_2K_splits && _cutting_planes_settings.c2k_splits.root != DISABLE_CUT) {
            for(const auto cut: find_violated_2k_splits(c2K_coefs, 1, 4, _cutting_planes_settings.c2k_splits.root, _lift,
                                tau_disc, tau)) {
                _report.num_2K_root++;
                violation_found = true;
                GRBLinExpr expr_lhs = 0;
                for(int v : cut.S2) {
                    for(int l = 2; l < _n; l++) {
                        expr_lhs += l*_x.at({cut.S1[0],v,l});
                        expr_lhs += l*_x.at({cut.S1[1],v,l});
                    }
                }

                GRBLinExpr expr_rhs = 0;
                int K = cut.S2.size();
                if(_lift) {
                    for(int l=2; l < _n; l++) {
                        expr_rhs += c2K_coefs[l][K]*_x.at({cut.S1[0],cut.S1[1],l});
                    }
                } else {
                    int rhs = c2K_coefs[2][K];
                    for(int l =3; l < _n; l++) {
                        rhs = std::min(rhs, c2K_coefs[l][K]);
                    }
                    expr_rhs = rhs;
                }
                
                _model->addConstr(expr_lhs >= expr_rhs);
            }
        }
        return violation_found;
    }

    double get_solver_obj() {
        return _model->getObjective().getValue();
    }
    void solve_model() {
        try {
            _model->optimize();
            _report.num_nodes = _model->get(GRB_DoubleAttr_NodeCount);
            _report.best_dual_bound = _model->get(GRB_DoubleAttr_ObjBound);
        } catch(GRBException &e) {
            std::cout << "EXCEPTION: " << e.getMessage() << std::endl;
        }
    }

    void construct_solution() {
        _best_sol = zero_matrix<double>(_inst.size());
        if(_model->get(GRB_IntAttr_SolCount) > 0) {
            for(int i=0; i < _n-1; i++) {
                for(int j=i+1; j < _n; j++) {
                    for(int l=2; l < _n; l++) {
                        double val = _x[{i,j,l}].get(GRB_DoubleAttr_X);
                        _best_sol[i][j] += l*val;
                        _best_sol[j][i] += l*val;
                    }
                }
            }
        }
    }

    void print_stats() {

    }

    public:
    SolverGurobi() :
        SolverInterface() {

    }

    void export_model(std::string filename) const {
        std::cout << "exporting" << std::endl;
        _model->write(filename);
    }
};


