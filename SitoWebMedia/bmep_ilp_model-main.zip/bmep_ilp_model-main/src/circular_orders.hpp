#pragma once

#include "instance.hpp"
#include <boost/graph/metric_tsp_approx.hpp>

struct CircularOrderCut {
    std::vector<int> tour;

    CircularOrderCut() {
        tour.clear();
    }

    CircularOrderCut(const std::vector<int> &tour) {
        this->tour = tour;
    }
};

std::vector<CircularOrderCut> find_circular_order_violation(double perc_tol, bool lifted, bool relax, bool exact,
        const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<double> &tau) {
    std::vector<CircularOrderCut> ret;

    int _n = tau.size();

    bool violation_found = false;
    for(int i = 0; i < _n; i++) {
        std::vector<int> tour;
        double cost;

        if(relax && lifted) {
            tour = greedy_nn_tsp_lifted(tau_disc, tau, i, _n-1);
            local_search_2opt_tsp_lifted(tau_disc, tau, tour);
            cost = compute_lifted_tour_cost(tau_disc, tau, tour);
        } else {
            tour = greedy_nn_tsp(tau, i, _n-1);
            local_search_2opt_tsp(tau, tour);
            cost = compute_tour_cost(tau, tour);
        }
        
        if(exact && !violation_found && cost > (4*_n-8)*(1-perc_tol)) {
            std::vector<int> cands;
            for(int j = 0; j < _n; j++) {
                if(i != j) {
                    cands.push_back(j);
                }
            }
            if(lifted) {
                tour = exact_tsp(tau, cands, 1e-3);
                cost = compute_tour_cost(tau, tour);
            } else {
                tour = exact_tsp_lifted(tau_disc, tau, cands, 1e-3);
                cost = compute_lifted_tour_cost(tau_disc, tau, tour);
            }
        }
        if(cost < (4*_n-8)*(1-perc_tol)) {
            violation_found = true;
            ret.push_back(CircularOrderCut(tour));
        }
        
    }

    return ret;
}