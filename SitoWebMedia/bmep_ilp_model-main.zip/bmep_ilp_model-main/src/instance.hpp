#pragma once

#include<vector>
#include<utility>
#include<string>

#include <filesystem>
#include <fstream>
#include <iostream>

#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/breadth_first_search.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/property_map/property_map.hpp>

template<typename T>
using NumMatrix = std::vector<std::vector<T>>;
using TaxaPair = std::array<int, 2>;

//graph definitions
typedef boost::adjacency_list<  boost::vecS,
                                boost::vecS,
                                boost::undirectedS,
                                boost::no_property,
                                boost::property<boost::edge_weight_t, double>> Graph;
typedef boost::property_map <Graph,
                      boost::edge_weight_t >::type EdgeWeightMap;

typedef Graph::vertex_descriptor Vertex;

typedef Graph::edge_descriptor Edge;

template<typename T>
std::pair<unsigned int, unsigned int> matrix_size(const NumMatrix<T> &mat) {
    return {mat.size(), mat[1].size()};
}

template<typename T>
NumMatrix<T> init_matrix(int n, int m, const T& v) {
    auto mat = NumMatrix<T>();
    mat.resize(n);
    for(int i=0;i < n;i++) {
        mat[i].assign(m, v);
    }
    return mat;
}


template<typename T>
NumMatrix<T> init_matrix(int n, const T& v) {
    return init_matrix<T>(n, n, v);
}

template<typename T>
NumMatrix<T> zero_matrix(int n, int m) {
    return init_matrix<T>(n, m, 0);
}

template<typename T>
NumMatrix<T> zero_matrix(int n) {
    return zero_matrix<T>(n, n);
}



template<typename T1, typename T2>
double compute_bmep_cost(const NumMatrix<T1>& inst, const NumMatrix<T2>& sol) {
    int n = matrix_size(inst).first;
    std::vector<double> powers_of_two(n,0);
    powers_of_two[0] = 1;
    for(int i = 1; i < n; i++) {
        powers_of_two[i] = powers_of_two[i-1]*2.0;
    }

    double cost=0;
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) { //uppertri
            cost += inst[i][j]*pow(2,1-sol[i][j]);
        }
    }
    return cost;
}


template<typename T1, typename T2>
double compute_scaled_bmep_cost(const NumMatrix<T1>& inst, const NumMatrix<T2>& sol) {
    int n = matrix_size(inst).first;

    double cost=0;
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) { //uppertri
            cost += inst[i][j]*pow(2,n-sol[i][j]+1);
        }
    }
    return cost;
}

template<typename T1, typename T2>
double compute_linear_cost(const NumMatrix<T1>& inst, const NumMatrix<T2>& sol) {
    int n = matrix_size(inst).first;
    double cost=0;
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) { //upper tri
            cost += 2*inst[i][j]*sol[i][j];
        }
    }
    return cost;
}

template<typename T>
NumMatrix<T> apply_perm(const NumMatrix<T> & mat, const std::vector<int> &pi) {
    int n = mat.size();
    NumMatrix<T> ret = init_matrix<T>(n, 0);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            ret[i][j] = mat[pi[i]][pi[j]];
        }
    }
    return ret;
}

template<typename T>
NumMatrix<T> apply_reverse_perm(const NumMatrix<T> & mat, const std::vector<int> &pi) {
    int n = mat.size();
    NumMatrix<T> ret = init_matrix<T>(n, 0);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            ret[pi[i]][pi[j]] = mat[i][j];
        }
    }
    return ret;
}

template<typename T>
void print(const NumMatrix<T> &mat) {
    for(int i=0; i < matrix_size(mat).first; i++) {
        for(int j=0; j < matrix_size(mat).second; j++) {
            std::cout << mat[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

template<typename Tout, typename Tin>
NumMatrix<Tout> convert(const NumMatrix<Tin> & mat) {
    auto out = zero_matrix<Tout>(matrix_size(mat).first, matrix_size(mat).second);
    for(int i = 0; i < matrix_size(mat).first; i++) {
        for(int j = 0; j < matrix_size(mat).second; j++) {
            out[i][j] = Tout(mat[i][j]);
        }
    }
    return out;
}

template<typename T>
NumMatrix<T> read_square_matrix(const std::string & filename, bool labeled=false) {
    if(!std::filesystem::exists(filename)) {
        return zero_matrix<T>(1,1);
    }
    
    std::ifstream ifs(filename);
    int n;
    ifs >> n;
    auto mat = zero_matrix<T>(n);
    std::string label;
    for(int i=0; i < n; i++) {
        if(labeled) {
            ifs >> label;
        }
        for(int j=0; j < n; j++) {
            ifs >> mat[i][j];
        }
    }
    ifs.close();
    return mat;
}

template<typename T>
bool write_square_matrix(const NumMatrix<T> & mat, const std::string & filename) {
    std::ofstream ofs(filename);
    int n = matrix_size(mat).first; 
    ofs << n << std::endl;
    for(int i=0; i < n; i++) {
        for(int j=0; j < n; j++) {
            ofs << mat[i][j] << " ";
        }
        ofs << std::endl;
    }
    ofs.close();
    return true;
}

template<typename T>
void crop(NumMatrix<T> &mat, int n) {
    mat.resize(n);
    for(int k=0; k < n; k++) {
        mat[k].resize(n);
    }    
}

//inplace contraction
template<typename T>
void contract(NumMatrix<T> &mat, int i, int j) {
    auto n = matrix_size(mat).first;

    if(i > j) {
        std::swap(i,j);
    }

    //updates distances from i
    for(int k = 0; k < n; k++) {
        if(k != i && k != j) {
            mat[i][k] = mat[k][i] = (mat[i][k]+mat[j][k]-mat[i][j])/2;
        }
    }

    //remove column
    for(int r=0; r < n;r++) {
        for(int c=j; c < n-1; c++) {
            mat[r][c] = mat[r][c+1];
        }
    }

    //remove row
    for(int c=0; c < n; c++) {
        for(int r=j; r < n-1;r++) {
            mat[r][c] = mat[r+1][c];
        }
    }

    crop(mat, n-1);
}

//assumes the graph has 2n-2 nodes and leaves labeled 1 to n

template<typename T>
Graph pathlengths_to_graph(NumMatrix<T> mat,double eps=1e-4) {
    int n = matrix_size(mat).first;
    Graph g(n);

    //helper to map contracted matrix's taxa and vertices of g
    std::vector<Vertex> index2vertex(n);
    for(int i=0; i < n; i++) {
        index2vertex[i] = i;
    }


    //contract until there are only two vertices;
    while(n > 2) {
        int i,j;

        //find pair at distance 2
        bool found=false;
        for(i=0; i < n; i++) {
            for(j=i+1; j < n; j++) {
                if(mat[i][j] >= 2-eps && mat[i][j] <= 2+eps) {
                    found=true;
                    break;
                }

            }
            if(found) {
                break;
            }
        }

        contract(mat, i, j);

        //create new vertex and connect it to contracted pair
        auto v = add_vertex(g);


        add_edge(v, index2vertex[i], 1, g);
        add_edge(v, index2vertex[j], 1, g);

        //update index two vertex map
        index2vertex[i] = v;
        for(int k=j+1;k < n;k++) {
            index2vertex[k-1] = index2vertex[k];
        }
        index2vertex.resize(n-1);

        n--;
    }

    //connect remaining two vertices
    add_edge(index2vertex[0], index2vertex[1], 1, g);
    return g;
}

template<typename T>
NumMatrix<T> graph_to_pathlengths(const Graph &g) {
    int n=(num_vertices(g)+2)/2;
    auto mat = zero_matrix<T>(n);
    for(int i = 0;i < n; i++) {
        std::vector<size_t> distances(num_vertices(g));
        auto recorder = record_distances(distances.data(), boost::on_tree_edge{});
        breadth_first_search(g, i, visitor(make_bfs_visitor(recorder)));
        for(int j = 0; j < n; j++) {
            mat[i][j] = distances[j];
        }
    }
    return mat;
}


