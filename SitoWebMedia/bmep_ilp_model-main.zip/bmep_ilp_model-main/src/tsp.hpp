#pragma once

#include "instance.hpp"
#include <boost/graph/metric_tsp_approx.hpp>



template<typename T>
T compute_tour_cost(const NumMatrix<T> &inst, const std::vector<int> &tour) {
    T cost = 0;
    for(int i = 0; i < tour.size(); i++) {
        cost += inst[tour[i]][tour[(i+1)%tour.size()]];
    }
    return cost;
}


template<typename T>
T compute_lifted_tour_cost(const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<T> & tau,
        const std::vector<int> &tour) {
    T cost = 0;
    for(int i = 0; i < tour.size(); i++) {
        cost += tau[tour[i]][tour[(i+1)%tour.size()]];
        for(int j = 0; j < tour.size(); j++) {
            if(i != j && (i+1)%tour.size() != j && (j+1)%tour.size() != i) {
                cost -= tau_disc[tour[i]][tour[j]][2]; //double counting
            }
        }
    }
    return cost;
}


template<typename T>
void local_search_2opt_tsp(const NumMatrix<T> & inst, std::vector<int> &tour) {
    T cost = compute_tour_cost(inst,tour);
    bool improv = true;
    while(improv) {
        improv = false;
        for(int i = 0; i < tour.size() && !improv; i++) {
            int i_succ = (i+1)%tour.size();
            for(int j = i+3; j < tour.size(); j++) {
                int j_prev = (j+tour.size()-1)%tour.size();
                
                double new_cost = cost - inst[tour[i]][tour[i_succ]] - inst[tour[j_prev]][tour[j]]
                    + inst[tour[j]][tour[i_succ]] + inst[tour[i]][tour[j_prev]];

                if(new_cost < cost-1e-4) {
                    cost = new_cost;
                    std::reverse(tour.begin()+i+1, tour.begin()+j);
                    improv = true;
                    break;
                } 
            }
        }

    }
}


template<typename T>
void local_search_2opt_tsp_lifted(const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<T> & tau,
        std::vector<int> &tour) {
    T cost = 0;
    for(int i = 0; i < tour.size(); i++) {
        cost += tau[tour[i]][tour[(i+1)%tour.size()]];
        cost += 2*tau_disc[tour[i]][tour[(i+1)%tour.size()]][2];

    }
    bool improv = true;
    while(improv) {
        improv = false;
        for(int i = 0; i < tour.size() && !improv; i++) {
            int i_succ = (i+1)%tour.size();
            int i_prev = (i+tour.size()-1)%tour.size();

            for(int j = i+3; j < tour.size(); j++) {
                int j_prev = (j+tour.size()-1)%tour.size();
                int j_succ = (j+1)%tour.size();

                double new_cost = cost;
                new_cost -= tau[tour[i]][tour[i_succ]];
                new_cost -= 2*tau_disc[tour[i]][tour[i_succ]][2];

                new_cost -= tau[tour[j_prev]][tour[j]];
                new_cost -= 2*tau_disc[tour[j_prev]][tour[j]][2];


                new_cost += tau[tour[j]][tour[i_succ]];
                new_cost += 2*tau_disc[tour[j]][tour[i_succ]][2];

                new_cost += tau[tour[i]][tour[j_prev]];
                new_cost += 2*tau_disc[tour[i]][tour[j_prev]][2];

                if(new_cost < cost-1e-4) {
                    cost = new_cost;
                    std::reverse(tour.begin()+i+1, tour.begin()+j);
                    improv = true;
                    break;
                } 
            }
        }
    }
}



template<typename T>
std::vector<int> greedy_nn_tsp(const NumMatrix<T> & inst, int start, int size) {
    int n = matrix_size(inst).first;

    std::vector<int> sol;
    sol.reserve(size);
    sol.push_back(start);
    
    std::set<int> missing;
    for(int k=0; k < n; k++) {
        if(k != start) {
            missing.insert(k);
        }
    }

    while(sol.size() < size) {
        int best_cand = -1;
        T best_cost = 0;
        for(auto cand: missing) {
            T cost = inst[sol[sol.size()-1]][cand];
            if(sol.size() == size-1) {
                cost += inst[cand][sol[0]];
            }
            if(best_cand == -1 || cost < best_cost) {
                best_cand = cand;
                best_cost = cost;
            }
        }
        sol.push_back(best_cand);
        missing.erase(best_cand);
    }

    return sol;
}


template<typename T>
std::vector<int> greedy_nn_tsp_lifted(const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<T> & tau,
        int start, int size) {
    int n = matrix_size(tau).first;

    
    std::vector<int> sol;
    sol.reserve(size);
    sol.push_back(start);
    
    std::set<int> missing;
    for(int k=0; k < n; k++) {
        if(k != start) {
            missing.insert(k);
        }
    }

    while(sol.size() < size) {
        int best_cand = -1;
        T best_cost = 0;
        for(auto cand: missing) {
            T cost = tau[sol[sol.size()-1]][cand] + 2*tau_disc[sol[sol.size()-1]][cand][2];
            if(sol.size() == size-1) {
                cost += tau[cand][sol[0]]+2*tau_disc[cand][sol[0]][2];
            }

            if(best_cand == -1 || cost < best_cost) {
                best_cand = cand;
                best_cost = cost;
            }
        }
        sol.push_back(best_cand);
        missing.erase(best_cand);
    }
    return sol;
}


template<typename T>
std::vector<int> greedy_1tree_tsp(const NumMatrix<T> & inst, const std::vector<int> &taxa) {
    std::vector<int> sol;
    Graph g(taxa.size());
    

    for(int i = 0; i < taxa.size(); i++) {
        for(int j = i+1; j < taxa.size(); j++) {
            auto e = add_edge(i, j, inst[taxa[i]][taxa[j]], g);
        }
    }
    //EdgeWeightMap weights (get(boost::edge_weight, g));
    std::vector<int> tour_g; //repeats the first vertex at the end
    metric_tsp_approx_tour(g, std::back_inserter(tour_g));
    for(int i = 0; i < tour_g.size()-1; i++) {
        sol.push_back(taxa[tour_g[i]]);
    }
    return sol;
}
//TODO write more robust code that does not call the executable 
template<typename T>
std::vector<int> exact_tsp(const NumMatrix<T> & inst, const std::vector<int> &taxa, double tol=1e-3) {
    std::vector<int> tour;

    std::ofstream ofs("concorde_temp.tsp");
    ofs << "NAME: temp" << std::endl;
    ofs << "TYPE: TSP" << std::endl;
    ofs << "COMMENT: temp" << std::endl;
    ofs << "DIMENSION: " << taxa.size() << std::endl;
    ofs << "EDGE_WEIGHT_TYPE: EXPLICIT" << std::endl;
    ofs << "EDGE_WEIGHT_FORMAT: FULL_MATRIX" << std::endl;
    ofs << "EDGE_WEIGHT_SECTION" << std::endl;
    for(int i = 0; i < taxa.size(); i++) {
        for(int j = 0; j < taxa.size(); j++) {
            ofs << int((1.0*inst[taxa[i]][taxa[j]])/tol) << " ";
        }
        ofs << std::endl;
    }
    ofs << "EOF" << std::endl;
    ofs.close();

    system("concorde concorde_temp.tsp > /dev/null");

    std::ifstream ifs("concorde_temp.sol");
    int sol_size;

    ifs >> sol_size;
    for(int i=0; i < sol_size; i++) {
        int cv;
        ifs >> cv;
        tour.push_back(taxa[cv]);     
    }
    
    return tour;
}

template<typename T>
std::vector<int> exact_tsp_lifted(const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<T> & tau,
        const std::vector<int> &taxa, double tol=1e-3) {
    std::vector<int> tour;

    std::ofstream ofs("concorde_temp.tsp");
    ofs << "NAME: temp" << std::endl;
    ofs << "TYPE: TSP" << std::endl;
    ofs << "COMMENT: temp" << std::endl;
    ofs << "DIMENSION: " << taxa.size() << std::endl;
    ofs << "EDGE_WEIGHT_TYPE: EXPLICIT" << std::endl;
    ofs << "EDGE_WEIGHT_FORMAT: FULL_MATRIX" << std::endl;
    ofs << "EDGE_WEIGHT_SECTION" << std::endl;
    for(int i = 0; i < taxa.size(); i++) {
        for(int j = 0; j < taxa.size(); j++) {
            double cost = tau[taxa[i]][taxa[j]] + 2*tau_disc[taxa[i]][taxa[j]][2];
            ofs << int(cost/tol) << " ";
        }
        ofs << std::endl;
    }
    ofs << "EOF" << std::endl;
    ofs.close();

    system("concorde concorde_temp.tsp > /dev/null");

    std::ifstream ifs("concorde_temp.sol");
    int sol_size;

    ifs >> sol_size;
    for(int i=0; i < sol_size; i++) {
        int cv;
        ifs >> cv;
        tour.push_back(taxa[cv]);     
    }
    
    return tour;
}