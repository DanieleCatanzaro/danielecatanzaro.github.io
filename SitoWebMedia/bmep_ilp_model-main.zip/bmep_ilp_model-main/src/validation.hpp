#pragma once
#include "instance.hpp"
#include "tsp.hpp"
#include "min_cut.hpp"
#include "common.hpp"

struct TriangularInequalityViolation {
    Triplet taxa; //3 taxa that determine the triangular inequality comparing
                  //taxa[0]-> taxa[1] with
                  //taxa[0] -> taxa[2] -> taxa[1]
    int slack; // slack in the triangular inequality
    bool weak; //true if slack < 2 false if slack >= 2 and odd   
};

struct BunemanViolation {
    std::array<int, 4> taxa;
    double lhs; // taxa[0][1] + taxa[2]taxa[3]
    double first_rhs; //taxa[0][1] + taxa[2]taxa[3]
    double second_rhs; //taxa[0][1] + taxa[2]taxa[3]
};

//taxa and lhs
struct KraftViolation {
    int taxa;
    double lhs;
};

struct ManifoldViolation {
    double lhs, rhs;
};

struct CircularOrderViolation {
    std::vector<int> tour;
    double cost;
};
//determines if the matrix is a pathlength matrix by recursive contraction
template<typename T>
bool is_pathlength_matrix(NumMatrix<T> mat) {
    bool valid=true;
    while(mat.size() > 3 && valid) {
        int i,j;
        bool found = false;
        for(i = 0; i < mat.size()-1; i++) {
            for(j = i+1; j < mat.size(); j++) {
                if(fabs(mat[i][j] - 2) < 1e-8) {
                    found = true;
                    break;
                }
            }
            if(found) {
                break;
            }
        }
        if(found) {
            contract(mat, i, j);
        } else {
            valid=false;
        }
    }
    if(mat.size() == 3) {
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                if(i == j) {
                    if(fabs(mat[i][j]) > 1e-8) {
                        valid = false;
                    }
                } else {
                    if(fabs(mat[i][j] - 2) > 1e-8) {
                        valid = false;
                    }
                }
            }
        }
    }

    return valid;
}



template<typename T>
std::vector<TriangularInequalityViolation> find_violated_triangular_inequalities(
        const NumMatrix<T> & mat, double tol=1e-6, bool stop_after_first=false) {
    std::vector<TriangularInequalityViolation> violations;
    int n = mat.size();
    bool violated = false;
    for(int i = 0; i < n && (!stop_after_first || !violated); i++) {
        for(int j = 0; j < n && (!stop_after_first || !violated); j++) {
            if(i == j) {
                continue;
            }
            for(int k = 0; k < n && (!stop_after_first || !violated); k++) {
                if(k !=i && k != j) {
                    bool cur_violated=false;
                    
                    T slack = mat[i][k]+mat[k][j] - mat[i][j];
                    bool weak_violation;
                    
                    if(slack < 2-tol) {
                        weak_violation = true;
                        cur_violated = true;
                        
                    } else if(slack%2!=0) {
                        weak_violation = false;
                        cur_violated = true;
                    }
                    if(cur_violated) {
                        TriangularInequalityViolation vio;
                        vio.taxa = {i,j,k};
                        vio.slack = slack;
                        vio.weak = weak_violation;
                        violations.emplace_back(vio);

                        violated = true;
                    }
                }
            }
        }
    }
    return violations;
}

template<typename T>
std::vector<BunemanViolation> find_violated_buneman_inequalities(
        const NumMatrix<T> & mat, double tol=1e-6, bool stop_after_first=false) {
    std::vector<BunemanViolation> violations;
    int n = mat.size();
    bool violated = false;
    for(int i = 0; i < n && (!stop_after_first || !violated); i++) {
        for(int j = 0; j < n && (!stop_after_first || !violated); j++) {
            if(i == j) {
                continue;
            }
            for(int p = 0; p < n && (!stop_after_first || !violated); p++) {
                if(p == i || p == j) {
                    continue;
                }
                for(int q = 0; q < n && (!stop_after_first || !violated); q++) {
                    if(q != i && q != j && q != p) {
                        T lhs = mat[i][j] + mat[p][q];
                        T first_rhs = mat[i][p] + mat[j][q];
                        T second_rhs = mat[i][q] + mat[j][p];
                        if(lhs > std::max(first_rhs, second_rhs)+tol) {
                            violated = true;
                            BunemanViolation violation;
                            violation.taxa = {i, j, p, q};
                            violation.lhs = lhs;
                            violation.first_rhs = first_rhs;
                            violation.second_rhs = second_rhs;
                            violations.emplace_back(violation);

                            violated = true;
                        }
                    }
                }
            }
        }
    }
    return violations;
}

template<typename T>
std::vector<KraftViolation> find_violated_kraft_inequalities(
        const NumMatrix<T> & mat, double tol=1e-6) {
    std::vector<KraftViolation> violations;
    int n = mat.size();

    for(int i = 0; i < n; i++) {
        double kraft_sum=0;
        for(int j = 0; j < n; j++) {
            if(i != j) {
                kraft_sum += pow(2,-mat[i][j]);
            }
        }
        if(fabs(kraft_sum-0.5) > tol) {
            KraftViolation violation;
            violation.taxa = i;
            violation.lhs = kraft_sum;
            violations.emplace_back(violation);
        }
    }

    return violations;
}

template<typename T>
std::vector<Cut> find_violated_generalized_kraft_inequalities(
    const NumMatrix<T> & mat, double tol=1e-6) {
    int n = mat.size();
    std::vector<Cut> violations;
    Cut cut = find_min_cut_xspace(mat);
    if(cut.cost < pow(2, n-2)-tol) {
        violations.push_back(cut);
    }
    return violations;
}

template<typename T>
bool is_manifold_violated(const NumMatrix<T> & mat, ManifoldViolation &violation,
        double tol=1e-6) {
    int n = mat.size();

    double manifold_sum = 0;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            manifold_sum += mat[i][j]*pow(2, -mat[i][j]);
        }
    }

    if(fabs(manifold_sum - (2*n-3)) > tol) {
        violation.lhs = manifold_sum;
        violation.rhs = 2*n-3;
        return true;
    }
    return false;
}

template<typename T>
std::vector<CircularOrderViolation> find_violated_circular_orders(
        const NumMatrix<T> & mat, double tol=1e-6) {
    std::vector<CircularOrderViolation> violations;
    int n = mat.size();
    for(int i = 0; i < n; i++) {
        std::vector<int> taxa;
        for(int k = 0; k < n; k++) {
            if(k != i) {
                taxa.push_back(k);
            }
        }
        
        std::vector<int> tour = exact_tsp(mat, taxa);
        int tour_cost = compute_tour_cost(mat, tour);
        if(tour_cost < 4*n-8-tol) {
            CircularOrderViolation violation;
            violation.tour = tour;
            violation.cost = tour_cost;

            violations.emplace_back(violation);
        }
    }

    return violations;
}
