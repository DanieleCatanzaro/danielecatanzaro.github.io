#include "instance.hpp"
#include "solver_common.hpp"
#include "solver_gurobi.hpp"

#include<boost/program_options.hpp>

namespace po = boost::program_options;

int main(int argc, char** argv) {
    //argument parsing
    std::string infilename, outfilename;
    bool labeled;
    std::string reportfilename;

    std::string instname;

    int n;
    double timelimit;
    bool fastme;
    ObjFunc obj_func;
    bool relax;
    int heuk;
    bool swa_branching;
    CircularOrderSepaMethod co_method;
    StrTriangularInqType str_type;
    BunemanType buneman_type;


    InstPerm perm_type;

    bool lift;
    bool localsearch;
    bool gki;
    bool weak_bunemans;    
    bool sep_2K;


    CuttingPlanesSettings cutting_planes_settings;
    

    po::options_description options("BMEP ILP Model Solver Options.\n\tThresholds are given as percentage of violation.\n\tSetting a threshold to -1 disables that insance of cutting plane.");
    po::variables_map vm;
    options.add_options()
        ("help,h", "Display help menu.")
        ("input,i", po::value<std::string>()->default_value(""), "Input file (Distance Matrix).")
        ("labeled", "Reads labeled instances. Labels are ignored but order is respected.")
        ("output,o", po::value<std::string>()->default_value(""), "output file (Path-length Matrix).")
        ("fastme", "Just call fastme after cropping the instances.")
        ("relax", "Relax Variable Integrality and solve only root node.")
        ("obj,O", po::value<char>()->default_value('B'), "Objective Function: (B)MEP or (L)inear")
        ("size,n",   po::value<int>()->default_value(-1), "crop to the first n taxa, set n < 0 to include all.")

        ("heuk,k", po::value<int>()->default_value(-1), "heuristic parameter, set to zero to disabled it")
        ("heuls,L",  "use local search for heuristic? requires fastme")

        ("swa", "Enables Stepwise Addition Branching Rule.")

        ("str", po::value<char>()->default_value('N'), "Method for Strengthening Triangular Inequalities: (N)one, (O)ne, (A)ll")
        ("buneman",po::value<char>()->default_value('N'), "Method for Buneman Inequalities: (N)one, (O)ne, (A)ll")
        
        ("lift",  "use lifting based on discretized tau")
        ("co", po::value<char>()->default_value('N'), "Method for Circular Order Separation: (G)reedy, (E)xact")
        ("coR", po::value<double>()->default_value(-1), "Threshold for separation Circular Ordering inequalities at the root node.")
        ("coN", po::value<double>()->default_value(-1), "Threshold for separation Circular Ordering inequalities inequalities at nonroot node.")

        ("gkiR", po::value<double>()->default_value(-1),  "Threshold for separation GKI inequalities at the root node.")
        ("gkiN", po::value<double>()->default_value(-1), "Threshold for separation GKI inequalities at nonroot node.")

        ("wbR", po::value<double>()->default_value(-1), "Threshold for separation Spread Quarts inequalities at the root node.")
        ("wbN", po::value<double>()->default_value(-1), "Threshold for separation Spread Quarts inequalities at nonroot node.")
        
        ("2KR", po::value<double>()->default_value(-1), "Threshold for separation 2-K split inequalities at the root node.")
        ("2KN", po::value<double>()->default_value(-1), "Threshold for separation 2-K split inequalities at nonroot node.")
        
        ("perm",po::value<char>()->default_value('N'), "Permutation type for input: (N)one, (G)reedy TSP, (E)xact TSP, (M)ax min entry, (m)in max entry")
        
        
        
        
        ("report,R", po::value<std::string>()->default_value(""), "File to write running report. Prints to terminal if empty")
        ("timelimit,t", po::value<double>()->default_value(-1), "Timelimit in seconds. Negative values disables timelimit.");
        
    po::store(po::parse_command_line(argc, argv, options), vm);    
    po::notify(vm);

    infilename = vm["input"].as<std::string>();
    outfilename = vm["output"].as<std::string>();
    reportfilename = vm["report"].as<std::string>();

    labeled = vm.count("labeled");

    int instname_begin = infilename.rfind("/");
    if(instname_begin == std::string::npos) {
        instname_begin = 0;
    } else {
        instname_begin +=1;
    }

    int instname_end = infilename.rfind(".");
    if(instname_end == std::string::npos) {
        instname_end = infilename.size();
    }

    instname = infilename.substr(instname_begin, instname_end);

    char _perm_type_char = vm["perm"].as<char>();

    if(_perm_type_char == 'G' || _perm_type_char == 'g') {
        perm_type = IP_TSP_GREEDY;
    } else if (_perm_type_char == 'E' || _perm_type_char == 'e') {
        perm_type = IP_TSP_EXACT;
    } else if (_perm_type_char == 'M') {
        perm_type = IP_MAX_MIN;
    } else if (_perm_type_char == 'm') {
        perm_type = IP_MIN_MAX;
    } else {
        perm_type = IP_NONE;
    }

    n = vm["size"].as<int>();
    timelimit = vm["timelimit"].as<double>();
    char obj_func_char = vm["obj"].as<char>();
    if(obj_func_char == 'B' || obj_func_char == 'b') {
        obj_func = OBJ_BMEP;
    } else {
        obj_func = OBJ_LINEAR;
    }
    fastme = vm.count("fastme");
    relax = vm.count("relax");
    heuk = vm["heuk"].as<int>();
    localsearch = vm.count("heuls");
    swa_branching = vm.count("swa");

    char co_sepa_char = vm["co"].as<char>();
    if(co_sepa_char == 'G' || co_sepa_char == 'g') {
        co_method = CO_GREEDY;
    } else if(co_sepa_char == 'E' || co_sepa_char == 'e') {
        co_method = CO_EXACT;
    }

    char str_type_char = vm["str"].as<char>();
    if(str_type_char == 'A' || str_type_char == 'a') {
        str_type = ST_ALL;
    } else if(str_type_char == 'O' || str_type_char == 'o') {
        str_type = ST_ONE;
    } else {
        str_type = ST_NONE;
    }

    char buneman_type_char = vm["buneman"].as<char>();
    if(buneman_type_char == 'A' || buneman_type_char == 'a') {
        buneman_type = BN_ALL;
    } else if(buneman_type_char == 'O' || buneman_type_char == 'o') {
        buneman_type = BN_ONE;
    } else {
        buneman_type = BN_NONE;
    }

    lift = vm.count("lift"); 

    cutting_planes_settings.circ_orders.root = vm["coR"].as<double>();
    cutting_planes_settings.circ_orders.non_root = vm["coN"].as<double>();

    if(cutting_planes_settings.circ_orders.root == -1 && cutting_planes_settings.circ_orders.non_root == -1) {
        co_method = CO_NONE;
    }
    cutting_planes_settings.GKI.root = vm["gkiR"].as<double>();
    cutting_planes_settings.GKI.non_root = vm["gkiN"].as<double>();
    gki = (cutting_planes_settings.GKI.root != -1 || cutting_planes_settings.GKI.non_root != -1);

    cutting_planes_settings.c2k_splits.root = vm["2KR"].as<double>();
    cutting_planes_settings.c2k_splits.non_root = vm["2KN"].as<double>();
    sep_2K = (cutting_planes_settings.c2k_splits.root != -1 || cutting_planes_settings.c2k_splits.non_root != -1);


    cutting_planes_settings.weak_bunemans.root = vm["wbR"].as<double>();
    cutting_planes_settings.weak_bunemans.non_root = vm["wbN"].as<double>();
    weak_bunemans = (cutting_planes_settings.weak_bunemans.root != -1 || cutting_planes_settings.weak_bunemans.non_root != -1);


    if(vm.count("help") || infilename.size() == 0) {
        std::cout << options << std::endl;
        return 0;
    }

    //solving
    NumMatrix<double> inst = read_square_matrix<double>(infilename, labeled);
    if(n < 0 || n >= matrix_size(inst).first) {
        n = matrix_size(inst).first;
    }
    crop(inst, n);
    
    if(fastme) {
        NumMatrix<int> sol = run_fastme<double,int>(inst, localsearch, localsearch);
        std::cout << "+++ " << instname << " | " << n << " | " << std::setprecision(16) << compute_bmep_cost(inst, sol) << " | "  << std::setprecision(16) << compute_scaled_bmep_cost(inst, sol) << std::endl;
    
    } else {
        SolverInterface* solver;

        solver = new SolverGurobi();

        solver->set_obj_func(obj_func);
        solver->relax_variables(relax);
        solver->set_lpnj_k(heuk);
        solver->set_lpnj_localsearch(localsearch);

        solver->set_use_swa_br(swa_branching);

        solver->set_strong_triangular_type(str_type);
        solver->set_buneman_type(buneman_type);

        solver->set_lift(lift);
        solver->set_circular_order_method(co_method);
        solver->set_separate_gki(gki);
        solver->set_separate_weak_bunemans(weak_bunemans);
        solver->set_separate_2K_splits(sep_2K);

        solver->set_cutting_planes_settings(cutting_planes_settings);
        solver->set_perm_type(perm_type);

        solver->set_timelimit(timelimit);


        NumMatrix<double> sol = solver->solve(inst);

        if(outfilename.size() > 0) {
            write_square_matrix(sol, outfilename);
        } else {
            print(sol);
        }
        Report report = solver->get_report();
        report.create_or_append(instname, reportfilename);

        delete solver;
    }
    return 0;
}