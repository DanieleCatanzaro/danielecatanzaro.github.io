#pragma once

#include "instance.hpp"
#include <boost/graph/one_bit_color_map.hpp>
#include <boost/graph/stoer_wagner_min_cut.hpp>

struct Cut {
    std::vector<int> S;
    std::vector<int> S_complement;
    double cost;
};


//Finds minimum cut
template<typename T>
 Cut find_min_cut(const NumMatrix<T> &mat) {
    int n = mat.size();
    Graph g(n);
    for(int i = 0; i < n; i++) {
        for(int j = i+1; j < n; j++) {
            add_edge(i,j, mat[i][j], g);
        }
    }

    auto colors =  boost::make_one_bit_color_map(num_vertices(g), get(boost::vertex_index, g));
    

    Cut cut;
    cut.cost = boost::stoer_wagner_min_cut(g, get(boost::edge_weight, g), boost::parity_map(colors));
    for(int i=0; i < n; i++) {
        if(get(colors, i)) {
            cut.S.push_back(i);
        } else {
            cut.S_complement.push_back(i);
        }
    }

    return cut;
 };



Cut find_min_cut_xspace(const std::vector<std::vector<std::vector<double>>> &mat_disc) {
    int n = mat_disc.size();
    NumMatrix<double> xmat = zero_matrix<double>(n);
    Graph g(n);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            for(int l = 2; l < n; l++) {
                xmat[i][j] += mat_disc[i][j][l]*pow(2, -l);
            }
        }
    }

    return find_min_cut(xmat);
 };
// Finds minimum cut with respect to x-space,
//i.e. distances are x_ij = 2^{n-1-tau_ij}
template<typename T>
Cut find_min_cut_xspace(const NumMatrix<T> &mat) {
    int n = mat.size();
    NumMatrix<T> xmat = zero_matrix<T>(n);
    Graph g(n);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            xmat[i][j] = pow(2, n-1-mat[i][j]);
        }
    }

    return find_min_cut(xmat);
 };


