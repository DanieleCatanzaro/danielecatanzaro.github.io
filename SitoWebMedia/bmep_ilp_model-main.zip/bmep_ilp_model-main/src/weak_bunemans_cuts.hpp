
#include "instance.hpp"

struct SpreadQuart {
    int u;
    int i,j,k;
    double lhs;

    SpreadQuart() : 
        SpreadQuart(-1,-1,-1,-1, 0) {

    }

    SpreadQuart(int u, int i, int j, int k, double lhs) {
        this->u = u;
        this->i = i;
        this->j = j;
        this->k = k;
        this->lhs = lhs;
    }
};


std::vector<SpreadQuart> separate_weak_bunemans_cuts(double perc_tol, bool lift,
    const std::vector<std::vector<std::vector<double>>> &tau_disc, const NumMatrix<double> & tau) {
    int n = tau.size();
    std::vector<SpreadQuart> ret;
    for(int u = 0; u < n; u++) {
        double cherry_u = 0;
        for(int v = 0; v < n; v++) {
            cherry_u += tau_disc[u][v][2];
        }
        for(int i = 0; i < n-2; i++) {
            if(i == u) {
                continue;
            }
            for(int j = i+1; j < n-1; j++) {
                if(j == u) {
                    continue;
                }
                for(int k=j+1; k < n; k++) {
                    if(k == u) {
                        continue;
                    }

                    double lhs = 0;
                    
                    lhs += tau[i][u] + tau[u][j] - tau[i][j];
                    lhs += tau[j][u] + tau[u][k] - tau[j][k];
                    lhs += tau[i][u] + tau[u][k] - tau[i][k];

                    if(lift) {
                        lhs -= 6*(cherry_u - tau_disc[u][i][2] - tau_disc[u][j][2] - tau_disc[u][k][2]);
                    }
                    if(lhs < 8*(1-perc_tol)) {
                        ret.push_back(SpreadQuart(u,i,j,k,lhs));
                    }
                }
            }
        }
    }
    return ret;
}