#pragma once
#include "instance.hpp"
#include <gurobi_c++.h>

struct HuffmanhedronFeasibilityCut {
    int r;
    std::vector<double> tau_coefs;
    double rhs;

    HuffmanhedronFeasibilityCut(int n, int r, double rhs=0.0) {
        this->rhs = rhs;
        this->r = r;
        tau_coefs.assign(n, 0);
    }
};

//debug only
void print(const HuffmanhedronFeasibilityCut& cut) {
    int n = cut.tau_coefs.size();
    for(int i = 0; i < n; i++) {
        if(fabs(cut.tau_coefs[i]) > 1e-8) {
            std::cout << cut.tau_coefs[i] << "tau[" << cut.r << "," << i << "] ";
        }
    }
    std::cout << "<= " << cut.rhs << std::endl;
}


std::vector<GRBVar> apply_extension(GRBModel* model, const std::vector<GRBVar> & cur_tau,
        std::vector<GRBConstr> &cons_nonzero_rhs) {
    int cur_n = cur_tau.size();
    std::vector<GRBVar> next_tau;
    
    for(int i = 0; i < cur_n-1; i++) {
        next_tau.emplace_back(model->addVar(-GRB_INFINITY, GRB_INFINITY,
            0, GRB_CONTINUOUS,
            "t["+std::to_string(cur_n+1) + "," + std::to_string(i) + "]e"));
        model->addConstr(next_tau[i] == cur_tau[i]);
    }
    for(int i = cur_n-1; i < cur_n+1; i++) {
        next_tau.emplace_back(model->addVar(-GRB_INFINITY, GRB_INFINITY,
            0, GRB_CONTINUOUS,
            "t["+std::to_string(cur_n+1) + "," + std::to_string(i) + "]e"));
        cons_nonzero_rhs.emplace_back(model->addConstr(next_tau[i] == cur_tau[cur_n-1]+1));       
    }

    return next_tau;
}

std::vector<GRBVar> apply_reflection(GRBModel* model, const std::vector<GRBVar> & cur_tau,
        int k, int l, char suf) {
    int cur_n = cur_tau.size();
    std::vector<GRBVar> next_tau;
    GRBVar lambda = model->addVar(0, GRB_INFINITY,
            0, GRB_CONTINUOUS,
            "lambda["+std::to_string(cur_n) + 
            "," + std::to_string(k) +
            "," + std::to_string(l) + "]" + suf);

    for(int i = 0; i < cur_n; i++) {
        next_tau.emplace_back(model->addVar(-GRB_INFINITY, GRB_INFINITY,
            0, GRB_CONTINUOUS,
            "t["+std::to_string(cur_n) + "," + std::to_string(i) + "]R["+
            std::to_string(k)+","+std::to_string(l)+"]" + suf));
        if(i == k) {
            model->addConstr(next_tau[i] == cur_tau[i] + lambda);
        } else if(i == l) {
            model->addConstr(next_tau[i] == cur_tau[i] - lambda);
        } else {
            model->addConstr(next_tau[i] == cur_tau[i]);
        }
        
    }

    return next_tau;
}

std::vector<GRBVar> generate_model_kaibel_n2_rec(GRBModel* model, int n,
        std::vector<GRBConstr> &cons_nonzero_rhs) {
    std::vector<GRBVar> tau;
    if(n == 2) {
        tau = {model->addVar(-GRB_INFINITY, GRB_INFINITY,0,GRB_CONTINUOUS,"t[2,0]"),
               model->addVar(-GRB_INFINITY, GRB_INFINITY,0,GRB_CONTINUOUS,"t[2,1]")};
        cons_nonzero_rhs.emplace_back(
            model->addConstr(tau[0] == 1));
        cons_nonzero_rhs.emplace_back(
            model->addConstr(tau[1] == 1));
    } else {
        tau = generate_model_kaibel_n2_rec(model, n-1, cons_nonzero_rhs);
        tau = apply_extension(model, tau, cons_nonzero_rhs);
        for(int i = n-3; i >= 0; i--) {
            tau = apply_reflection(model, tau, i,i+1, 'b');
        }
        for(int i = n-2; i >= 0; i--) {
            tau = apply_reflection(model, tau, i,i+1, 't');
        }
    }
    return tau;
}
std::vector<HuffmanhedronFeasibilityCut> find_feasibility_cuts_kaibel_n2(
        const NumMatrix<double> &frac_tau) {
    std::vector<HuffmanhedronFeasibilityCut> cuts;
    int n = frac_tau.size();

    //construct model
    GRBEnv env;
    GRBModel model(env);
    model.set(GRB_IntParam_OutputFlag, 0);
    model.set(GRB_IntParam_InfUnbdInfo, 1);
    //todo get constraint pool to get rhs

    std::vector<GRBConstr> cons_nonzero_rhs;
    std::vector<GRBVar> tau = generate_model_kaibel_n2_rec(&model, n-1, cons_nonzero_rhs); //rooted
    for(int i = 0; i < n-1; i++) {
        tau[i].set(GRB_DoubleAttr_Obj, 0);
    }
    //create linking constraints (only ones involving variables of the original problem)
    std::vector<GRBConstr> linking_cons;
    for(int i = 0; i < n-1; i++) {
        linking_cons.emplace_back(model.addConstr(tau[i] == 0));
    }
    //model.write("test_data/hext.lp");
    for(int r = 0; r < n; r++) {
        //change rhs
        for(int i = 0; i < n-1; i++) {
            if(i < r) {
                linking_cons[i].set(GRB_DoubleAttr_RHS, frac_tau[r][i]-1);
            } else {
                linking_cons[i].set(GRB_DoubleAttr_RHS, frac_tau[r][i+1]-1);
            }
        }

        //solve
        model.optimize();

         //extract cuts
        if(model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE) {
            std::cout << "INFEASEABLE PRIMAL: generating cut" << std::endl;
            HuffmanhedronFeasibilityCut cut(n, r);
            for(int i = 0; i < n-1; i++) {
                double lambda = linking_cons[i].get(GRB_DoubleAttr_FarkasDual);
                if(i < r) {
                    cut.tau_coefs[i] = -lambda;
                } else {
                    cut.tau_coefs[i+1] = -lambda;
                }
                cut.rhs -= lambda;
            }
            for(const auto &con: cons_nonzero_rhs) {
                cut.rhs += con.get(GRB_DoubleAttr_FarkasDual)*con.get(GRB_DoubleAttr_RHS);
            }
            //print(cut);
            cuts.emplace_back(cut);
        }
       
        
    }
    return cuts;
}