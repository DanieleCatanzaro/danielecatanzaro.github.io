#pragma once
#include <fstream>
#include <iostream>
#include <filesystem>

struct Report {
    int n;
    double sol;
    int node_best_sol;
    double best_dual_bound;
    double time;
    int num_nodes;
    int num_sol_rejected;

    double first_root_bound;
    double last_root_bound;

    //cuts
    int num_circular_order_root;
    int num_circular_order_search;

    int num_gki_root;
    int num_gki_search;

    int num_spread_quad_root;
    int num_spread_quad_search;


    int num_2K_root;
    int num_2K_search;

    int num_buneman_root;
    int num_buneman_search;



    Report() :
        n(-1),
        sol(0),
        node_best_sol(-1),
        time(0),
        num_nodes(0),
        num_sol_rejected(0),
        first_root_bound(0),
        last_root_bound(0),
        num_circular_order_root(0),
        num_circular_order_search(0),
        num_gki_root(0),
        num_gki_search(0),
        num_spread_quad_root(0),
        num_spread_quad_search(0),
        num_2K_root(0),
        num_2K_search(0),
        num_buneman_root(0),
        num_buneman_search(0) {
    }

    void append(std::string instname, std::string filename) {
        //compute derived data
        double gap = (sol-best_dual_bound)*100/sol;
        int num_total_cuts = num_circular_order_root+num_circular_order_search
            +num_gki_root+num_gki_search
            +num_spread_quad_root+num_spread_quad_search
            +num_2K_root+num_2K_search
            +num_buneman_root+num_buneman_search;

        std::stringstream ss;
        ss.precision(12);
        ss << instname << " | " << n;
        ss << " | " << sol << " | " << time;
        ss << " | " << node_best_sol;
        ss << " | " << first_root_bound << " | " << last_root_bound;
        ss << " | " << best_dual_bound;
        ss << " | " << gap << " | " << num_nodes << " | " << num_sol_rejected;
        ss << " | " << num_circular_order_root << " | " << num_circular_order_search;
        ss << " | " << num_gki_root << " | " << num_gki_search;
        ss << " | " << num_spread_quad_root << " | " << num_spread_quad_search;
        ss << " | " << num_2K_root << " | " << num_2K_search;
        ss << " | " << num_buneman_root << " | " << num_buneman_search;
        ss << " | " << num_total_cuts << "\n";

        if(filename.size() == 0) {
            std::cout << ss.str();
        } else {
            std::ofstream f;
            f.open(filename, std::ofstream::app);
            f << ss.str();
            f.close();
        }
    }

    void create(std::string instname, std::string filename) {
        std::stringstream ss;
        ss << "Instance | N";
        ss << " | Best Sol | Time (s)";
        ss << " | Node Best Sol";
        ss << " | First Root DB | Last Root BD";
        ss << " | Best Dual Bound";
        ss << " | Final Gap (%) | Nodes | INF";
        ss << " | CO@Root | CO@Search";
        ss << " | GKI@Root | GKI@Search";
        ss << " | EHC@Root | EHC@Search";
        ss << " | 2K@Root | 2K@Search";
        ss << " | 4PT@Root | 4PT@Search";
        ss << " | Overall Cuts\n";

        if(filename.size() == 0) {
            std::cout << ss.str();
        } else {
            std::ofstream f;
            f.open(filename);
            f << ss.str();
            f.close();
        }
    }

    void create_or_append(std::string instname, std::string filename) {
        if(filename.size() > 0 && !std::filesystem::exists(filename)) {
            create(instname, filename);
        }
        append(instname, filename);
    }
};