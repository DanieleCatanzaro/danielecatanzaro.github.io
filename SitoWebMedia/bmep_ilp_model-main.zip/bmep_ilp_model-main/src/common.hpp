#pragma once

#include <array>
using Pair = std::array<int, 2>;
using Triplet = std::array<int, 3>;
