//Tests for lpnj.hpp
#include "../src/instance.hpp"
#include "../src/lpnj.hpp"

#define BOOST_TEST_MODULE LPNJTest
#include <boost/test/included/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_simple_inst) {
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique6_balanced.inst");
    NumMatrix<double> relax = inst;
    NumMatrix<int> target_sol = read_square_matrix<int>("test_data/unique6_balanced.sol");

    NumMatrix<int> sol;
    lpnj(inst, relax, sol, inst.size()*inst.size());
    BOOST_CHECK(sol == target_sol);
}


BOOST_AUTO_TEST_CASE(test_simple_relax) {
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique6_balanced.inst");
    NumMatrix<double> relax = inst;
    NumMatrix<int> target_sol = read_square_matrix<int>("test_data/unique6_balanced.sol");

    NumMatrix<int> sol;
    lpnj(inst, relax, sol, 1);
    BOOST_CHECK(sol == target_sol);
}


BOOST_AUTO_TEST_CASE(test_simple_relax_and_inst) {
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique6_balanced.inst");
    NumMatrix<double> relax = read_square_matrix<double>("test_data/unique6_cat.inst");


    NumMatrix<int> inst_sol = read_square_matrix<int>("test_data/unique6_balanced.sol");
    NumMatrix<int> relax_sol = read_square_matrix<int>("test_data/unique6_cat.sol");


    NumMatrix<int> sol_small_k;
    lpnj(inst, relax, sol_small_k, 1);

    NumMatrix<int> sol_large_k;
    lpnj(inst, relax, sol_large_k, inst.size()*inst.size());

    BOOST_CHECK(sol_small_k == relax_sol);
    BOOST_CHECK(sol_large_k == inst_sol);
}