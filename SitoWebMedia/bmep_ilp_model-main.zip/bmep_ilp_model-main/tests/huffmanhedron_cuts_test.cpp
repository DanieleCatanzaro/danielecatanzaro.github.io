#include "../src/instance.hpp"
#include "../src/huffmanhedron_cuts.hpp"

#define BOOST_TEST_MODULE HuffmanhedronCutsTest
#include <boost/test/included/unit_test.hpp>


bool violates(const NumMatrix<double> & sol, const HuffmanhedronFeasibilityCut& cut) {
    
    double lhs = 0.0;
    for(int i = 0; i < sol.size(); i++) {
        lhs += sol[cut.r][i]*cut.tau_coefs[i];
    }

    return lhs > cut.rhs + 1e-8;
}

BOOST_AUTO_TEST_CASE(test_trivial) {
    NumMatrix<double> sol = init_matrix<double>(3, 2);

    BOOST_CHECK_EQUAL(find_feasibility_cuts_kaibel_n2(sol).size(), 0);
}

BOOST_AUTO_TEST_CASE(test_simple) {
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique12.sol");
    int n = sol.size();

    NumMatrix<double> infeas = init_matrix<double>(n, n-1);

    BOOST_CHECK_EQUAL(find_feasibility_cuts_kaibel_n2(sol).size(), 0);
    auto cuts = find_feasibility_cuts_kaibel_n2(infeas);
    BOOST_ASSERT(cuts.size() == n);
    for(const auto & cut : cuts) {
        BOOST_CHECK(!violates(sol, cut));
        BOOST_CHECK(violates(infeas, cut));

    }
}
