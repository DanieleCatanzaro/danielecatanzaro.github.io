#include "../src/instance.hpp"
#include "../src/min_cut.hpp"

#define BOOST_TEST_MODULE MinCutTest
#include <boost/test/included/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_simple) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/min_cut.inst");
    int n = matrix_size(inst).first;


    Cut cut =  find_min_cut_xspace(inst);
    BOOST_CHECK_SMALL(cut.cost - 9, 1e-6);

    double actual_cost = 0;
    for(auto u: cut.S) {
        for(auto v: cut.S_complement) {
            actual_cost += pow(2,n-1-inst[u][v]);
        }
    } 
    BOOST_CHECK_SMALL(cut.cost - actual_cost, 1e-6);
}