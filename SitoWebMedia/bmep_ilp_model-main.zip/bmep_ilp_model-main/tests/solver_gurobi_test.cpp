//Tests for Instance.hpp
#include "../src/instance.hpp"
#include "../src/solver_gurobi.hpp"

#define BOOST_TEST_MODULE SolverGurobiTest
#include <filesystem>
#include <boost/test/included/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_simple) {
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique6.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique6_sol.inst");
    int n = inst.size();
    SolverGurobi solver = SolverGurobi();
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/gurobi_simple.lp");
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK(fabs(solver_sol[i][j]-sol[i][j]) < 1e-6);
        }
    }
}

BOOST_AUTO_TEST_CASE(test_linear) {
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique6.inst");
    NumMatrix<double> sol_bmep = read_square_matrix<double>("test_data/unique6_sol.inst");

    SolverGurobi solver = SolverGurobi();
    solver.set_obj_func(OBJ_LINEAR);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/gurobi_simple.lp");
    print(solver_sol);
    BOOST_CHECK(compute_linear_cost(inst, solver_sol) < compute_linear_cost(inst, sol_bmep));
}

BOOST_AUTO_TEST_CASE(test_heu) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    int n = inst.size();
    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    NumMatrix<double> solver_sol = solver.solve(inst);
    print(solver_sol);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK(fabs(solver_sol[i][j]-sol[i][j]) < 1e-6);
        }
    }
}



BOOST_AUTO_TEST_CASE(test_circular_order) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique12.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique12.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_circular_order_method(CO_GREEDY);
    NumMatrix<double> solver_sol = solver.solve(inst);
    
    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}


BOOST_AUTO_TEST_CASE(test_generalized_kraft) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_separate_gki(true);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/gurobi_test_generalized_kraft.lp");
    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}



BOOST_AUTO_TEST_CASE(test_strong_tri_one) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_strong_triangular_type(ST_ONE);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/model_test_strong_tri_one.lp");
    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}

BOOST_AUTO_TEST_CASE(test_strong_tri_all) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_strong_triangular_type(ST_ALL);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/model_test_strong_tri_all.lp");

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}



BOOST_AUTO_TEST_CASE(test_buneman_one) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_buneman_type(BN_ONE);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/model_test_bumenan_one.lp");

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}

BOOST_AUTO_TEST_CASE(test_buneman_all) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_buneman_type(BN_ALL);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/model_test_bumenan_all.lp");

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}



BOOST_AUTO_TEST_CASE(test_gki) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique8.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique8.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_separate_gki(true);
    NumMatrix<double> solver_sol = solver.solve(inst);
    solver.export_model("test_data/model_test_bumenan_all.lp");

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}


BOOST_AUTO_TEST_CASE(test_extended_cuts) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique12.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique12.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_separate_extended_cuts(true);
    NumMatrix<double> solver_sol = solver.solve(inst);

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}


BOOST_AUTO_TEST_CASE(test_spread_quarts_cuts) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique12.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique12.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_separate_spread_quarts(true);
    NumMatrix<double> solver_sol = solver.solve(inst);

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}

BOOST_AUTO_TEST_CASE(test_2K_splits) {
    //requires non trivial instances
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique12.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique12.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_separate_2K_splits(true);
    NumMatrix<double> solver_sol = solver.solve(inst);

    BOOST_ASSERT(matrix_size(solver_sol) == matrix_size(sol));
    int n = matrix_size(sol).first;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            BOOST_CHECK_SMALL(solver_sol[i][j] - sol[i][j], 1e-6);
        }
    }
}


BOOST_AUTO_TEST_CASE(test_report) {
    //requires non trivial instances

    std::string report_filename = "./test_data/unique12_report.txt";
    NumMatrix<double> inst = read_square_matrix<double>("test_data/unique12.inst");
    NumMatrix<double> sol = read_square_matrix<double>("test_data/unique12.sol");

    SolverGurobi solver = SolverGurobi();
    solver.set_lpnj_k(1);
    solver.set_circular_order_method(CO_GREEDY);
    solver.set_separate_spread_quarts(true);
    solver.set_separate_gki(true);
    
    NumMatrix<double> solver_sol = solver.solve(inst);
    Report report = solver.get_report();
    std::filesystem::remove(report_filename);

    report.create_or_append("unique12", report_filename);

    BOOST_CHECK(std::filesystem::exists(report_filename));
}