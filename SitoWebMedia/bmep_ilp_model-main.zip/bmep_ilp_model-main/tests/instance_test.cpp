//Tests for Instance.hpp
#include "../src/instance.hpp"

#define BOOST_TEST_MODULE InstanceTest
#include <boost/test/included/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_allocation) {
    auto inst = zero_matrix<double>(6);
    BOOST_ASSERT(matrix_size(inst) == std::make_pair(6u,6u));

    inst[1][2] = inst[2][1] = 1;

    for(int i = 0; i < 6; i++) {
        for(int j = 0; j < 6; j++) {
            if((i == 1 && j == 2) || (i == 2 && j == 1)) {
                BOOST_CHECK_EQUAL(inst[i][j], 1);
            } else {
                BOOST_CHECK_EQUAL(inst[i][j], 0);
            }
        }
    }

}


BOOST_AUTO_TEST_CASE(test_read_and_print) {
    auto inst = read_square_matrix<int>("test_data/unique4.inst");
    BOOST_ASSERT(matrix_size(inst) == std::make_pair(4u,4u));
    for(int i = 0; i < 4; i++) {
        for(int j = 0; j < 4; j++) {
            if((i == 0 && j == 1) || (i == 1 && j == 0) ||
               (i == 2 && j == 3) || (i == 3 && j == 2)) {
                BOOST_CHECK_EQUAL(inst[i][j], 1);
            } else if(i == j) {
                BOOST_CHECK_EQUAL(inst[i][j], 0);
            } else {
                BOOST_CHECK_EQUAL(inst[i][j], 2);
            }
        }
    }

    print(inst);
}

BOOST_AUTO_TEST_CASE(test_read_labeled) {
    auto inst = read_square_matrix<int>("test_data/unique6_cat.inst");
    auto labeled_inst = read_square_matrix<int>("test_data/labeled_unique6_cat.inst", true);

    BOOST_ASSERT(matrix_size(inst) == std::make_pair(6u,6u));
    BOOST_ASSERT(matrix_size(labeled_inst) == std::make_pair(6u,6u));
    for(int i = 0; i < 6; i++) {
        for(int j = 0; j < 6; j++) {
            BOOST_CHECK_EQUAL(inst[i][j], labeled_inst[i][j]);
        }
    }

    print(inst);
}
BOOST_AUTO_TEST_CASE(test_init) {
    auto mat = init_matrix(6,6,1);
    BOOST_ASSERT(matrix_size(mat) == std::make_pair(6u,6u));

    for(int i = 0; i < 6; i++) {
        for(int j = 0; j < 6; j++) {
            BOOST_CHECK_EQUAL(mat[i][j], 1);
        }
    }
}

BOOST_AUTO_TEST_CASE(test_conversition) {
    auto inst_int = read_square_matrix<int>("test_data/unique4.inst");
    auto inst_double = read_square_matrix<double>("test_data/unique4.inst");

    auto converted = convert<double>(inst_int);
    BOOST_CHECK(converted == inst_double);
}

BOOST_AUTO_TEST_CASE(test_write_and_compare) {
    auto original_inst = read_square_matrix<int>("test_data/unique4.inst");
    BOOST_CHECK(write_square_matrix(original_inst, "test_data/unique4w.inst"));

    auto inst_from_file = read_square_matrix<int>("test_data/unique4w.inst");

    BOOST_CHECK(original_inst == inst_from_file);
}


BOOST_AUTO_TEST_CASE(test_costs) {
    auto inst = read_square_matrix<int>("test_data/unique6.inst");
    auto sol = read_square_matrix<int>("test_data/unique6_sol.inst");

    BOOST_CHECK_EQUAL(compute_bmep_cost(inst, sol), 15.0);
    BOOST_CHECK_EQUAL(compute_linear_cost(inst, sol), 876.0);
    BOOST_CHECK_EQUAL(compute_scaled_bmep_cost(inst, sol), 15*64);
}


BOOST_AUTO_TEST_CASE(test_permutations) {
    auto inst = read_square_matrix<int>("test_data/unique6_cat.inst");
    BOOST_CHECK(inst == apply_perm(inst, {0,1,2,3,4,5}));

    auto rev_but_one = apply_perm(inst, {0,5,4,3,2,1});
    print(rev_but_one);
    for(int i = 1; i < 6; i++) {
        for(int j = 1; j < 6; j++) {
            BOOST_CHECK_EQUAL(rev_but_one[i][j], 0);
        }
        BOOST_CHECK_EQUAL(rev_but_one[0][i], 7-i);
        BOOST_CHECK_EQUAL(rev_but_one[i][0], 7-i);
    }
    

    BOOST_CHECK(inst == apply_reverse_perm(rev_but_one, {0,5,4,3,2,1}));
}

BOOST_AUTO_TEST_CASE(test_crop) {
    auto inst = read_square_matrix<int>("test_data/unique4.inst");
    crop(inst,3);


    BOOST_ASSERT(matrix_size(inst) == std::make_pair(3u, 3u));
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            if((i == 0 && j == 1) || (i == 1 && j == 0)) {
                BOOST_CHECK_EQUAL(inst[i][j], 1);
            } else if(i == j) {
                BOOST_CHECK_EQUAL(inst[i][j], 0);
            } else {
                BOOST_CHECK_EQUAL(inst[i][j], 2);
            }
        }
    }

}

BOOST_AUTO_TEST_CASE(test_contraction) {
    auto mat = read_square_matrix<int>("test_data/unique4.inst");
    auto claw = read_square_matrix<int>("test_data/claw3.inst");

    std::vector<std::pair<int,int>> contractions = {{0,1}, {2,3}, {1,0}, {3,2}};
    for(auto contraction: contractions) {
        auto cur_mat = mat;
        contract(cur_mat, contraction.first, contraction.second);
        BOOST_CHECK(cur_mat == claw);
    }

    contract(mat, 0, 1);
    BOOST_CHECK(matrix_size(mat) == std::make_pair(3u,3u));
    contract(mat, 0, 1);
    BOOST_CHECK(matrix_size(mat) == std::make_pair(2u,2u));
}

BOOST_AUTO_TEST_CASE(test_graph) {
    NumMatrix<int> mat = read_square_matrix<int>("test_data/unique8.sol");
    Graph g = pathlengths_to_graph(mat);

    NumMatrix<int> new_mat = graph_to_pathlengths<int>(g);

    BOOST_ASSERT(matrix_size(mat) == matrix_size(new_mat));
    BOOST_CHECK(mat == new_mat);
}
