//Tests for newick.hpp
#include "../src/instance.hpp"
#include "../src/newick.hpp"

#define BOOST_TEST_MODULE NewickTest
#include <boost/test/included/unit_test.hpp>



BOOST_AUTO_TEST_CASE(test_parse) {

    Graph new_inst_graph = parse_newick_file("test_data/unique8_sol.nw");

    NumMatrix<int> inst = read_square_matrix<int>("test_data/unique8.sol");
    Graph inst_graph = pathlengths_to_graph(inst);

    NumMatrix<int> new_inst = graph_to_pathlengths<int>(new_inst_graph);

    BOOST_CHECK(inst == new_inst);
}

BOOST_AUTO_TEST_CASE(test_write) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/unique8.sol");
    Graph inst_graph = pathlengths_to_graph(inst);

    write_newick_file(inst_graph, "test_data/unique8_solw.nw");

    Graph new_inst_graph = parse_newick_file("test_data/unique8_solw.nw");
    NumMatrix<int> new_inst = graph_to_pathlengths<int>(new_inst_graph);

    BOOST_CHECK(inst == new_inst);
}
