//Tests for newick.hpp
#include "../src/instance.hpp"
#include "../src/newick.hpp"
#include "../src/fastme.hpp"

#define BOOST_TEST_MODULE FastMETest
#include <boost/test/included/unit_test.hpp>



BOOST_AUTO_TEST_CASE(test_not_change) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/unique8.inst");
    NumMatrix<int> sol = read_square_matrix<int>("test_data/unique8.sol");

    NumMatrix<int> new_sol = run_fastme_local_search(inst, sol, true, true);

    BOOST_CHECK(sol == new_sol);
}


BOOST_AUTO_TEST_CASE(test_change) {
    NumMatrix<int> cat_inst = read_square_matrix<int>("test_data/unique6_cat.inst");

    NumMatrix<int> cat_sol = read_square_matrix<int>("test_data/unique6_cat.sol");
    NumMatrix<int> bal_sol = read_square_matrix<int>("test_data/unique6_balanced.sol");
    
    
    NumMatrix<int> opt_sol = run_fastme_local_search(cat_inst, bal_sol, true, true);
    NumMatrix<int> same_sol = run_fastme_local_search(cat_inst, bal_sol, false, false);

    BOOST_CHECK(bal_sol != opt_sol);
    BOOST_CHECK(bal_sol == same_sol);
    
    BOOST_CHECK(cat_sol == opt_sol);
}