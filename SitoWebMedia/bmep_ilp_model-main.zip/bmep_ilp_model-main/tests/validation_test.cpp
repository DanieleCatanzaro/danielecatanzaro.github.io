//Tests validation.hpp
#include "../src/instance.hpp"
#include "../src/tsp.hpp"
#include "../src/validation.hpp"
#define BOOST_TEST_MODULE ValidationTest
#include <boost/test/included/unit_test.hpp>


BOOST_AUTO_TEST_CASE(test_validate_pl) {
    auto valid_inst = read_square_matrix<int>("test_data/unique12.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_manifold.sol");

    BOOST_CHECK(is_pathlength_matrix(valid_inst));
    BOOST_CHECK(!is_pathlength_matrix(invalid_inst));
}

BOOST_AUTO_TEST_CASE(test_triangular_inequalities) {
    auto valid_inst = read_square_matrix<int>("test_data/vio_manifold.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_tri.sol");

    BOOST_CHECK_EQUAL(find_violated_triangular_inequalities(valid_inst, 0).size(), 0);
    auto violations = find_violated_triangular_inequalities(invalid_inst, 0);
    BOOST_CHECK(violations.size() > 0);
    //TODO better checks
}


BOOST_AUTO_TEST_CASE(test_buneman) {
    auto valid_inst = read_square_matrix<int>("test_data/unique12.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_buneman_and_more.sol");

    BOOST_CHECK_EQUAL(find_violated_buneman_inequalities(valid_inst, 0).size(), 0);
    auto violations = find_violated_buneman_inequalities(invalid_inst, 0);
    BOOST_CHECK(violations.size() > 0);
}


BOOST_AUTO_TEST_CASE(test_kraft) {
    auto valid_inst = read_square_matrix<int>("test_data/vio_tri.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_kraft_and_more.sol");
    auto empty = find_violated_kraft_inequalities(valid_inst, 1e-6);
    auto violations = find_violated_kraft_inequalities(invalid_inst, 1e-6);

    BOOST_CHECK_EQUAL(empty.size(), 0);
    BOOST_CHECK(violations.size() > 0);
}

BOOST_AUTO_TEST_CASE(test_generalized_kraft) {
    auto valid_inst = read_square_matrix<int>("test_data/vio_tri.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_gki.sol");
    auto empty = find_violated_generalized_kraft_inequalities(valid_inst, 1e-6);
    auto violations = find_violated_generalized_kraft_inequalities(invalid_inst, 1e-6);

    BOOST_CHECK_EQUAL(empty.size(), 0);
    BOOST_CHECK(violations.size() > 0);
}

BOOST_AUTO_TEST_CASE(test_manifold) {
    auto valid_inst = read_square_matrix<int>("test_data/unique12.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_manifold.sol");

    ManifoldViolation violation;
    BOOST_CHECK(!is_manifold_violated(valid_inst, violation, 1e-6));
    BOOST_CHECK(is_manifold_violated(invalid_inst, violation, 1e-6));
}


BOOST_AUTO_TEST_CASE(test_circular_order) {
    auto valid_inst = read_square_matrix<int>("test_data/vio_manifold.sol");
    auto invalid_inst = read_square_matrix<int>("test_data/vio_kraft_and_more.sol");

    ManifoldViolation violation;
    auto empty = find_violated_circular_orders(valid_inst, 0);
    auto violations = find_violated_circular_orders(invalid_inst, 0);
    BOOST_CHECK_EQUAL(empty.size(), 0);
    BOOST_CHECK(violations.size() > 0);
}