#include "../src/precompute_2K_coefs.hpp"

#define BOOST_TEST_MODULE Precompute2KCoefsTEst
#include <boost/test/included/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_8) {
    auto coefs = precompute_2K_coefs(8);
    BOOST_CHECK_EQUAL(coefs[2][1], 6);
    BOOST_CHECK_EQUAL(coefs[2][2], 14);
    BOOST_CHECK_EQUAL(coefs[2][3], 24);
    BOOST_CHECK_EQUAL(coefs[2][4], 34);
    BOOST_CHECK_EQUAL(coefs[2][5], 46); 
    BOOST_CHECK_EQUAL(coefs[2][6], 56); 

    BOOST_CHECK_EQUAL(coefs[3][1], 5);
    BOOST_CHECK_EQUAL(coefs[3][2], 12);
    BOOST_CHECK_EQUAL(coefs[3][3], 21);
    BOOST_CHECK_EQUAL(coefs[3][4], 30);
    BOOST_CHECK_EQUAL(coefs[3][5], 41);
    BOOST_CHECK_EQUAL(coefs[3][6], 50);

    BOOST_CHECK_EQUAL(coefs[4][1], 6);
    BOOST_CHECK_EQUAL(coefs[4][2], 12);
    BOOST_CHECK_EQUAL(coefs[4][3], 20);
    BOOST_CHECK_EQUAL(coefs[4][4], 30);
    BOOST_CHECK_EQUAL(coefs[4][5], 40);
    BOOST_CHECK_EQUAL(coefs[4][6], 48);

    BOOST_CHECK_EQUAL(coefs[5][1], 7);
    BOOST_CHECK_EQUAL(coefs[6][1], 8);
}

BOOST_AUTO_TEST_CASE(test_6) {
    auto coefs = precompute_2K_coefs(6);
    BOOST_CHECK_EQUAL(coefs[2][1], 6);
    BOOST_CHECK_EQUAL(coefs[2][2], 14);
    BOOST_CHECK_EQUAL(coefs[2][3], 24);
    BOOST_CHECK_EQUAL(coefs[2][4], 32);//not 34

    BOOST_CHECK_EQUAL(coefs[3][1], 5);
    BOOST_CHECK_EQUAL(coefs[3][2], 12);
    BOOST_CHECK_EQUAL(coefs[3][3], 21);
    BOOST_CHECK_EQUAL(coefs[3][4], 28);//not 30


    BOOST_CHECK_EQUAL(coefs[4][1], 6);
    BOOST_CHECK_EQUAL(coefs[4][2], 12);
    BOOST_CHECK_EQUAL(coefs[4][3], 20);
    BOOST_CHECK_EQUAL(coefs[4][4], 28);//not 30

    BOOST_CHECK_EQUAL(coefs[5][1], 7);
    BOOST_CHECK_EQUAL(coefs[5][2], 14);
    BOOST_CHECK_EQUAL(coefs[5][3], 21);
    BOOST_CHECK_EQUAL(coefs[5][4], 28);
}