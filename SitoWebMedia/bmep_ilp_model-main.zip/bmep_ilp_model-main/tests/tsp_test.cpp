#include "../src/instance.hpp"
#include "../src/tsp.hpp"

#define BOOST_TEST_MODULE TSPTest
#include <boost/test/included/unit_test.hpp>



BOOST_AUTO_TEST_CASE(test_nn_greedy) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/tsp2.inst");
    int n = matrix_size(inst).first;
    std::vector<int> tour = greedy_nn_tsp(inst, 0, n);

    BOOST_ASSERT(tour.size() == n);
    BOOST_CHECK_EQUAL(compute_tour_cost(inst, tour), 60);
}

BOOST_AUTO_TEST_CASE(test_1tree_greedy) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/tsp2.inst");
    int n = matrix_size(inst).first;
    std::vector<int> taxa;
    for(int i = 0; i < n; i++) {
        taxa.push_back(i);
    }

    std::vector<int> tour = greedy_1tree_tsp(inst, taxa);

    BOOST_ASSERT(tour.size() == n);
    BOOST_CHECK_EQUAL(compute_tour_cost(inst, tour), 70);
}


BOOST_AUTO_TEST_CASE(test_1tree_greedy_2opt) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/tsp2.inst");
    int n = matrix_size(inst).first;
    std::vector<int> taxa;
    for(int i = 0; i < n; i++) {
        taxa.push_back(i);
    }

    std::vector<int> tour = greedy_1tree_tsp(inst, taxa);
    local_search_2opt_tsp(inst, tour);

    BOOST_ASSERT(tour.size() == n);
    BOOST_CHECK(compute_tour_cost(inst, tour) < 70);
}

BOOST_AUTO_TEST_CASE(test_simple_exact) {
    NumMatrix<int> inst = read_square_matrix<int>("test_data/tsp2.inst");
    int n = matrix_size(inst).first;
    std::vector<int> taxa;
    for(int i = 0; i < n; i++) {
        taxa.push_back(i);
    }

    std::vector<int> tour = exact_tsp(inst, taxa);

    BOOST_ASSERT(tour.size() == n);
    BOOST_CHECK_EQUAL(compute_tour_cost(inst, tour), 59);
}


